create view foodsubs_foods(labels, url, cat1, cat2, cat3, cat4, subs, notes, pronunciation) as
SELECT ARRAY(SELECT jsonb_array_elements_text(
                            foodsubs_etl.fs_fix_labels(foodsubs_foods_raw.possible_names)::jsonb) AS jsonb_array_elements_text) AS labels,
       foodsubs_foods_raw.url,
       btrim(foodsubs_foods_raw.page_hierarchy1)                                                                                AS cat1,
       btrim(foodsubs_foods_raw.page_hierarchy2)                                                                                AS cat2,
       btrim(foodsubs_foods_raw.page_hierarchy3)                                                                                AS cat3,
       btrim(foodsubs_foods_raw.page_hierarchy4)                                                                                AS cat4,
       ARRAY(
               SELECT jsonb_array_elements_text('[]'::jsonb) AS jsonb_array_elements_text)                                      AS subs,
       foodsubs_foods_raw.notes,
       foodsubs_foods_raw.pronunciation
FROM foodsubs_etl.foodsubs_foods_raw;

alter table foodsubs_foods
    owner to mb;

