create function etl_spn_top_foods_data(start integer, num integer) returns void
    strict
    SET search_path = spn_food_etl, spn_etl, food, gen
    language sql
as
$$
SELECT etl_spn_food(spn_id)
 FROM spn_top_ingr_in
 OFFSET start LIMIT num;
$$;

alter function etl_spn_top_foods_data(integer, integer) owner to mb;

