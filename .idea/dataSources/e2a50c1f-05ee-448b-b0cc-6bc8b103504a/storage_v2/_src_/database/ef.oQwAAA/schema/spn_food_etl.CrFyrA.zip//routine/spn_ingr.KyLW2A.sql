create function spn_ingr(ingr_id integer)
    returns TABLE(spn_id integer, food_cat text, food_label text, image_uri text, units text[], orig_json json)
    strict
    SET search_path = spn_food_etl, spn_etl, food, gen
    language sql
as
$$
SELECT
  (c ->> 'id')::integer spn_id,
  c ->> 'aisle' food_cat,
  c ->> 'name' food_label,
  c ->> 'image' image_uri,
  ARRAY(SELECT json_array_elements_text(c -> 'possibleUnits')) units,
  c orig_json
 FROM (
   SELECT content::json c FROM
   http_get(
    'https://api.spoonacular.com/food/ingredients/' || $1 || '/information' ||
    '?amount=1&apiKey=' ||
    (SELECT spn_api_key FROM api_key))
  ) a
 ;
$$;

alter function spn_ingr(integer) owner to mb;

