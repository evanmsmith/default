create view food_main_name(food, food_label) as
SELECT food_name.food,
       food_name.food_label
FROM food.food_name
WHERE food_name.prio = 1;

alter table food_main_name
    owner to mb;

