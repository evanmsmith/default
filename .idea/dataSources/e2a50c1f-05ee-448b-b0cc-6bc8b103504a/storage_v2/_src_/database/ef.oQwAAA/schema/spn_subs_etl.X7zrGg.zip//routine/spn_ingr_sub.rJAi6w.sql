create function spn_ingr_sub(ingr_id integer)
    returns TABLE(spn_id integer, subs_id bigint, subs_component_id bigint, food_name text, food_amount text, food_units text, subs_component_name text, subs_component_amount text, subs_component_units text)
    strict
    SET search_path = spn_subs_etl, spn_food_etl, spn_etl, food, gen
    language sql
as
$$
WITH 
    api_request AS (
        SELECT content::json c FROM
        http_get(
            'https://api.spoonacular.com/food/ingredients/' || $1 || '/substitutes' ||
            '?amount=1&apiKey=' ||
            (SELECT spn_api_key FROM api_key))
    ),
    raw_substitutes AS (
        SELECT  subs_id,
        		api_request.c ->> 'ingredient' AS food_name,
        		raw_substitutes AS substitutes
        FROM    api_request,
        		json_array_elements_text(api_request.c -> 'substitutes') WITH ORDINALITY a(raw_substitutes, subs_id)
    ),
    parsed_original_info AS (
        SELECT  $1 spn_id,
        		food_name,
        		subs_id,
        		substring(substitutes, '([/\d\w]+)\s\w') food_amount,
                substring(substitutes, '\s(\w+)\s=') food_units
        FROM    raw_substitutes
    ),
    parsed_subs_info AS (
        SELECT  raw_substitutes.subs_id,
        		subs_component_id,
        		substring(split_substitute, '([/\d\w]+)\s\w+\s[\w\s]+\s?') subs_component_amount,
                substring(split_substitute, '[\d\w]+\s(\w+)\s[\w\s]+\s?') subs_component_units,
                substring(split_substitute, '[\d\w]+\s\w+\s([\w\s]+)\s?') subs_component_name
        FROM    raw_substitutes,
        		unnest(regexp_split_to_array(substring(substitutes, '=(.+)'), '\s((and)|\+)\s')) WITH ORDINALITY a(split_substitute, subs_component_id)
    ),
    normalized_substitution AS (
        SELECT  O.spn_id,
                O.subs_id,
                S.subs_component_id,
                O.food_name,
                O.food_amount,
                O.food_units,
                S.subs_component_name,
                S.subs_component_amount,
                S.subs_component_units
        FROM    parsed_original_info O
        JOIN    parsed_subs_info S USING(subs_id)
    )
	SELECT      *
	FROM        normalized_substitution
    ORDER BY    subs_id,
                subs_component_id
    ;
$$;

alter function spn_ingr_sub(integer) owner to mbtemp;

