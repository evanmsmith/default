create function get_person_diet(text) returns bigint
    stable
    strict
    language sql
as
$$
SELECT diet FROM person_diet WHERE person = get_person($1)
$$;

alter function get_person_diet(text) owner to mb;

