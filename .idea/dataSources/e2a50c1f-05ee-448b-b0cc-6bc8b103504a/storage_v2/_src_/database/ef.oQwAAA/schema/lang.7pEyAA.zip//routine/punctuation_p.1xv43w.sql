create function punctuation_p(text) returns boolean
    immutable
    language sql
as
$$
SELECT $1 ~ '^[!"#$%&''()*+, -./:;<=>?@[\]^_`{|}~]*$';
$$;

alter function punctuation_p(text) owner to mb;

