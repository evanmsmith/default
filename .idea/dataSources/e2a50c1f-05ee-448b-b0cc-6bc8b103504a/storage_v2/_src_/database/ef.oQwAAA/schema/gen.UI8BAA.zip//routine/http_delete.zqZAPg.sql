create function http_delete(uri character varying) returns gen.http_response
    language sql
as
$$
SELECT http(('DELETE', $1, NULL, NULL, NULL)::http_request)
$$;

alter function http_delete(varchar) owner to mb;

