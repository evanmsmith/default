create function num_frac_p(text) returns boolean
    immutable
    language sql
as
$$
    -- NOTE ignores whitespace
 --
 -- From http://unicodefractions.com/
 SELECT $1 ~ E'^[0-9\u00bd\u2153\u2154\u00bc\u00be\u2155\u2156\u2157\u2158\u2159\u215a\u2150\u215b\u215c\u215d\u215e\u2151\u2152\u2189 ]*$';
$$;

alter function num_frac_p(text) owner to mb;

