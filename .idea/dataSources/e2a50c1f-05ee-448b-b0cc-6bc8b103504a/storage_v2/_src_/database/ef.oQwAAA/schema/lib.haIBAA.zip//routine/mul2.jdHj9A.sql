create function mul2(integer, integer) returns integer
    immutable
    language sql
as
$$
SELECT $1 * $2;
$$;

alter function mul2(integer, integer) owner to mb;

