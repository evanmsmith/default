create function assert(_cond boolean, _message text) returns void
    language plpgsql
as
$$
BEGIN
 IF NOT _cond THEN
  RAISE EXCEPTION '%', _message;
 END IF;
END
$$;

alter function assert(boolean, text) owner to mb;

