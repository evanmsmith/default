create function etl_det_to_bom() returns trigger
    SET search_path = food_etl, lang, food, recipe, gen
    language plpgsql
as
$$
BEGIN
 INSERT INTO bom_det (rec, food, bom_qty)
 SELECT
  NEW.rec,
  NEW.food,
  1 -- FUTURE insert actual quantity
 ON CONFLICT ON CONSTRAINT bom_det_pkey DO UPDATE SET food = NEW.food
 ;
 RETURN null;
END
$$;

alter function etl_det_to_bom() owner to mb;

