create view etl_det_human (rec, rec_label, lineno, section, food_label, qty_descr, confidence, orig_text) as
SELECT etl_det.rec,
       recipe.rec_label,
       etl_det.lineno,
       etl_det.section,
       food.get_food(food) AS food_label,
       etl_det.qty_descr,
       etl_det.confidence,
       etl_det.orig_text
FROM food_etl.etl_det
         JOIN recipe.recipe USING (rec)
         LEFT JOIN food.food USING (food);

alter table etl_det_human
    owner to mb;

