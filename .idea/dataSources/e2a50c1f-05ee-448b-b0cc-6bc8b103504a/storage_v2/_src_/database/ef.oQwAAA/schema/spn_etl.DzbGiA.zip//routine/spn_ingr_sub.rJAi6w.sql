create function spn_ingr_sub(ingr_id integer)
    returns TABLE(spn_id bigint, subs_id integer, ingredient_name text, ingredient_amount text, ingredient_units text, subs_component_id bigint, subs_component_name text, subs_component_amount text, subs_component_units text)
    stable
    SET search_path = spn_etl, food, gen
    language sql
as
$$
WITH 
    api_request AS (
        SELECT content::json c FROM
        http_get(
            'https://api.spoonacular.com/food/ingredients/' || 1007 || '/substitutes' ||
            '?amount=1&apiKey=' ||
            (SELECT spn_api_key FROM api_key))
    ),
    raw_substitutes AS (
        SELECT  subs_id,
        		api_request.c ->> 'ingredient' AS ingredient_name,
        		raw_substitutes AS substitutes
        FROM    api_request,
        		json_array_elements_text(api_request.c -> 'substitutes') WITH ORDINALITY a(raw_substitutes, subs_id)
    ),
    parsed_original_info AS (
        SELECT  1007 spn_id,
        		ingredient_name,
        		subs_id,
        		substring(substitutes, '^([/\d\w]+)\s\w+') ingredient_amount,
                substring(substitutes, '\s(\w+)\s=') ingredient_units
        FROM    raw_substitutes
    ),
    parsed_subs_info AS (
        SELECT  raw_substitutes.subs_id,
        		subs_component_id,
        		substring(split_substitute, '([/\d\w]+)\s\w+\s[\w\s]+\s?') subs_component_amount,
                substring(split_substitute, '[\d\w]+\s(\w+)\s[\w\s]+\s?') subs_component_units,
                substring(split_substitute, '[\d\w]+\s\w+\s([\w\s]+)\s?') subs_component_name
        FROM    raw_substitutes,
        		unnest(regexp_split_to_array(substring(substitutes, '=(.+)'), '\s((and)|\+)\s')) WITH ORDINALITY a(split_substitute, subs_component_id)
    ),
    normalized_substitution AS (
        SELECT  *
        FROM    parsed_original_info
        JOIN    parsed_subs_info USING(subs_id)
    )
	SELECT      *
	FROM        normalized_substitution
    ORDER BY    subs_id,
                subs_component_id
$$;

alter function spn_ingr_sub(integer) owner to mbtemp;

