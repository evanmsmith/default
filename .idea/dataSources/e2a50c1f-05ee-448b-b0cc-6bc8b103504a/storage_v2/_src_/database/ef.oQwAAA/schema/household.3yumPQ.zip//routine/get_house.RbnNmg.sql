create function get_house(bigint) returns gen.label_t
    stable
    strict
    SET search_path = household, recipe, food, diet, gen
    language sql
as
$$
SELECT house_label FROM house WHERE house = $1
$$;

alter function get_house(bigint) owner to mb;

