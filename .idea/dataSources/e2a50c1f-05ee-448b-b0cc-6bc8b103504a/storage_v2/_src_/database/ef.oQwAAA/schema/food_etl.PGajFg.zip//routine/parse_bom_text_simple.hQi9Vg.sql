create function parse_bom_text_simple(text)
    returns TABLE(orig_text text, food_descr text, qty_descr text, confidence real, metadata jsonb)
    immutable
    strict
    language sql
as
$$
    -- Use a trivial heuristic to distinguish quantity information at
 -- start of line.
 --
 -- FUTURE This code is a joke, but it works. Not hard to refactor
 -- coming at it with a fresh mind.
 WITH tok AS (SELECT * FROM tokenize_text($1)),
 qty_candidate AS (
  SELECT
   pos,
   min(pos) OVER (ORDER BY pos ASC) min_pos,
   max(pos) OVER (ORDER BY pos DESC) max_pos
  FROM
   tok
  WHERE
   kind IN ('number', 'punctuation') OR
   kind = 'word' AND ARRAY['conj']::lang_part_t[] <@ part OR
   lemma IN (SELECT lemma FROM uom_words)
 ),
 qty_gap AS (
  SELECT prevpos gap_pos
  FROM
  (
   SELECT pos, lag(pos) OVER (ORDER BY pos) prevpos
   FROM tok JOIN qty_candidate USING (pos)
  ) a
  WHERE prevpos != pos - 1
  ORDER BY pos LIMIT 1
 ),
 qty_part AS (
  SELECT
   string_agg(lexeme, ' ') qty_text,
   min(least(max_pos, gap_pos)) qty_end
  FROM
   tok
   JOIN qty_candidate USING (pos)
   LEFT JOIN qty_gap ON true
  WHERE
   min_pos = 1 AND
   pos BETWEEN 1 AND least(max_pos, gap_pos)
 )
 SELECT
  $1 orig_text,
  (
   SELECT
    string_agg(lemma, ' ') food_text
   FROM
    tok
    LEFT JOIN qty_part ON true
   WHERE
    qty_end IS NULL OR pos > qty_end
  ) food_descr,
  (
   SELECT qty_text FROM qty_part
  ) qty_descr,
  (
   SELECT 0.5::real -- FUTURE - quantify the confidence
  ) confidence,
  (SELECT array_to_json(array_agg(row_to_json(tok))) FROM tok)::jsonb metadata
 ;
$$;

alter function parse_bom_text_simple(text) owner to mb;

