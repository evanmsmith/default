create view diet_rec(diet, rec, rec_ont, rec_class, food_pref) as
SELECT diet_rec_class.diet,
       rec_class.rec,
       diet_rec_class.rec_ont,
       diet_rec_class.rec_class,
       diet_rec_class.food_pref
FROM diet.diet_rec_class
         JOIN recipe.rec_class USING (rec_ont, rec_class);

alter table diet_rec
    owner to mb;

