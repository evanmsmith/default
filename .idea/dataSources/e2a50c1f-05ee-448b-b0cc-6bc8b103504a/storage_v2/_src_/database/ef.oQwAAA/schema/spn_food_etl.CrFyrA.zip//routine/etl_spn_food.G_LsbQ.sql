create function etl_spn_food(ingr_id integer)
    returns TABLE(food bigint)
    strict
    SET search_path = spn_food_etl, spn_etl, food, gen
    language sql
as
$$
WITH spn_data AS (
  SELECT * FROM spn_ingr($1)
  WHERE food_label IS NOT NULL
 ),
 existing_food AS (
  SELECT food FROM spn_food WHERE
   food_main_name = (SELECT food_label FROM spn_data)
 ),
 ins_food AS (
  INSERT INTO food
  SELECT
  WHERE
   (SELECT food_label FROM spn_data) NOT IN
    (SELECT food_main_name FROM spn_food)
  RETURNING food
 ),
 actual_food AS (
  SELECT
   coalesce(existing_food.food, ins_food.food) food
  FROM
   (VALUES (1)) dual
   LEFT JOIN existing_food ON true
   LEFT JOIN ins_food ON true
 ),
 ins_food_names AS (
  INSERT INTO food_name (food, food_label)
  SELECT food, food_label
  FROM actual_food, spn_data
  ON CONFLICT ON CONSTRAINT food_name_pkey DO NOTHING
 ),
 ins_food_class AS (
  INSERT INTO food_class (food, food_ont, food_class, food_class_note)
  SELECT
   food,
   get_food_ont('generic'),
   btrim(fc.food_cat),
   'from spn'
  FROM
   actual_food,
   spn_data
   JOIN LATERAL regexp_split_to_table(spn_data.food_cat, '[;,]|and')
    fc(food_cat) ON true
  WHERE fc.food_cat IS NOT NULL AND fc.food_cat NOT IN ('', ' ')
  ON CONFLICT ON CONSTRAINT food_class_pkey DO NOTHING
 ),
 ins_spn_food AS (
  INSERT INTO spn_food
  SELECT
   food,
   spn_id,
   image_uri,
   units,
   orig_json,
   food_label
  FROM
   actual_food,
   spn_data
  ON CONFLICT ON CONSTRAINT spn_food_pkey DO NOTHING
 )
 SELECT
  food
 FROM
  actual_food
 ;
$$;

alter function etl_spn_food(integer) owner to mb;

