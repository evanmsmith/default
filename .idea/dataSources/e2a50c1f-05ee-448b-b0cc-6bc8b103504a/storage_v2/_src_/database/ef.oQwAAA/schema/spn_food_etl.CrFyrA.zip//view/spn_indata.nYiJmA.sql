create view spn_indata(food, food_label, spn_id, image_uri, units, orig_json) as
SELECT food.food,
       food_main_name.food_label,
       spn_food.spn_id,
       spn_food.image_uri,
       spn_food.units,
       jsonb_pretty(spn_food.orig_json::jsonb) AS orig_json
FROM food.food
         JOIN food.food_main_name USING (food)
         JOIN spn_food_etl.spn_food USING (food);

alter table spn_indata
    owner to mb;

