create function notify_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
 IF array_length(TG_ARGV, 1) = 1 THEN
  EXECUTE 'NOTIFY ' || TG_ARGV[0];
 ELSIF array_length(TG_ARGV, 1) = 2 THEN
  EXECUTE 'NOTIFY ' || TG_ARGV[0] || ', ' || TG_ARGV[1];
 ELSE
  RAISE EXCEPTION 'Invalid number of arguments to notify_trigger()';
 END IF;
 RETURN null;
END;
$$;

alter function notify_trigger() owner to mb;

