create function get_rec(gen.label_t) returns bigint
    stable
    strict
    SET search_path = recipe, food, gen
    language sql
as
$$
SELECT rec FROM recipe WHERE rec_label = $1
$$;

alter function get_rec(gen.label_t) owner to mb;

