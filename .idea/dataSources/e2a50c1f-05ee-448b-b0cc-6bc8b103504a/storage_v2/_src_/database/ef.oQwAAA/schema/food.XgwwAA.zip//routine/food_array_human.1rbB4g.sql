create function food_array_human(bigint[]) returns text
    stable
    SET search_path = food, lang, gen
    language sql
as
$$
SELECT
  string_agg(main_label, ', ' ORDER BY main_label)
 FROM
  unnest($1) foods(food)
  JOIN food_name_human USING (food)
$$;

alter function food_array_human(bigint[]) owner to mb;

