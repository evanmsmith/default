create function etl_spn_top_foods_ids(_max integer) returns void
    strict
    SET search_path = spn_food_etl, spn_etl, food, gen
    language sql
as
$$
INSERT INTO spn_top_ingr_in
  SELECT ingr_name, spn_id::integer
  FROM spn_top_ingr
  LIMIT _max;
$$;

alter function etl_spn_top_foods_ids(integer) owner to mb;

