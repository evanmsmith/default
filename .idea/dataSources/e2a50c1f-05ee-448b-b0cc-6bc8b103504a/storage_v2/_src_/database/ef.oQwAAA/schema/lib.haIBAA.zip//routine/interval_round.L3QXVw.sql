create function interval_round(base_interval interval, round_interval interval) returns interval
    stable
    language sql
as
$$
SELECT ((EXTRACT(epoch FROM $1)::INTEGER + EXTRACT(epoch FROM $2)::INTEGER / 2)
        / EXTRACT(epoch FROM $2)::INTEGER * EXTRACT(epoch FROM $2)::INTEGER) * '1 second'::interval
$$;

alter function interval_round(interval, interval) owner to mb;

