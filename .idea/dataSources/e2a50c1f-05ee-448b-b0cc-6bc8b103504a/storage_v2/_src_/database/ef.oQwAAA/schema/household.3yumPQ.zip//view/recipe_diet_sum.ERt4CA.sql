create view recipe_diet_sum (diet, rec, food_pref, foods_total, foods_in_diet, foods_tolerated, tolerated) as
SELECT f.diet,
       f.rec,
       ROW ((f.food_pref).preference * 0.3::double precision +
            COALESCE((r.food_pref).preference, 0::double precision) * 0.7::double precision, LEAST(
               (f.food_pref).tolerance,
               COALESCE((r.food_pref).tolerance, 1::double precision)))::diet.food_pref_t AS food_pref,
       f.foods_total,
       f.foods_in_diet,
       f.foods_tolerated,
       f.tolerated
FROM household.recipe_diet_food_sum f
         LEFT JOIN diet.diet_rec r USING (diet, rec);

alter table recipe_diet_sum
    owner to mb;

