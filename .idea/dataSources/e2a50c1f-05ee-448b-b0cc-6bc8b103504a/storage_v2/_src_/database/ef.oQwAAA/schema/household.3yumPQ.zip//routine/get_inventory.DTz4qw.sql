create function get_inventory(gen.label_t) returns bigint
    stable
    strict
    SET search_path = household, recipe, food, diet, gen
    language sql
as
$$
SELECT inv
 FROM
  house
  JOIN inventory USING (house)
 WHERE house_label = $1
$$;

alter function get_inventory(gen.label_t) owner to mb;

