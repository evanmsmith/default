create view diet_possible_recipe
            (inv, diet, rec, food_pref, rec_human, foods_total, num_present, num_missing, present_foods,
             missing_foods) as
SELECT possible_recipe.inv,
       recipe_diet_sum.diet,
       possible_recipe.rec,
       recipe_diet_sum.food_pref,
       recipe.get_rec(possible_recipe.rec) AS rec_human,
       recipe_diet_sum.foods_total,
       possible_recipe.num_present,
       possible_recipe.num_missing,
       possible_recipe.present_foods,
       possible_recipe.missing_foods
FROM household.possible_recipe
         JOIN household.recipe_diet_sum USING (rec)
WHERE recipe_diet_sum.tolerated
ORDER BY ((recipe_diet_sum.food_pref).preference) DESC;

alter table diet_possible_recipe
    owner to mb;

