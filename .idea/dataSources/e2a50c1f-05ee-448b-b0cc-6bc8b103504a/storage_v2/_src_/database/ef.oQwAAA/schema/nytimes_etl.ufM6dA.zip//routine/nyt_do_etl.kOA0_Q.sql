create function nyt_do_etl(start integer, num integer, min_rating integer)
    returns TABLE(number integer, min_rec bigint, max_rec bigint)
    strict
    language sql
as
$$
SELECT count(*)::integer, min(rec), max(rec) FROM
  (SELECT
    etl_recipe_bom_simple(
     bom,
     'nyt',
     backref,
     title,
     (
      SELECT
       array_agg(
        row(
         get_rec_ont('tag'),
         unnest,
         null
        )::rec_ont_info_t
       )
      FROM
       unnest(tag)
     ),
     rating,
     num_ratings
    ) rec
   FROM
    nyt_extract($1, $2, $3)
  ) etl;
$$;

alter function nyt_do_etl(integer, integer, integer) owner to mb;

