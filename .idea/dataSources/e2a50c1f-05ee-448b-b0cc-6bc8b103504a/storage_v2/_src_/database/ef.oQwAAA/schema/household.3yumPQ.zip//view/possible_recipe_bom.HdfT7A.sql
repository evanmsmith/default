create view possible_recipe_bom(rec, inv, food, sufficient, shortage) as
SELECT recipe_shortage.rec,
       recipe_shortage.inv,
       recipe_shortage.food,
       recipe_shortage.shortage <= 0::numeric         AS sufficient,
       GREATEST(recipe_shortage.shortage, 0::numeric) AS shortage
FROM household.recipe_shortage;

alter table possible_recipe_bom
    owner to mb;

