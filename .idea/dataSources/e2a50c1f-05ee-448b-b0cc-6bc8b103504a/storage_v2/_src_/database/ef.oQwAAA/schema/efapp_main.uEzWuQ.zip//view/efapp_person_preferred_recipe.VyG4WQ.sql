create view efapp_person_preferred_recipe("Person", "Diets", "Recipe", "Preference Score %") as
SELECT household.get_person(person_recipe_diet_sum.person)                                    AS "Person",
       person_recipe_diet_sum.diet_label                                                      AS "Diets",
       recipe.get_rec(person_recipe_diet_sum.rec)                                             AS "Recipe",
       ((person_recipe_diet_sum.food_pref).preference * 100::double precision)::numeric(5, 2) AS "Preference Score %"
FROM household.person_recipe_diet_sum
WHERE person_recipe_diet_sum.tolerated
ORDER BY ((person_recipe_diet_sum.food_pref).preference) DESC, (recipe.get_rec(person_recipe_diet_sum.rec));

alter table efapp_person_preferred_recipe
    owner to mb;

