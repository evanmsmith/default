create view food_name_human(food, main_label, other_labels) as
SELECT food_main_name.food,
       food_main_name.food_label    AS main_label,
       string_agg(
               CASE
                   WHEN food_name.food_label::text <> food_main_name.food_label::text THEN food_name.food_label::text
                   ELSE NULL::text
                   END, ', '::text) AS other_labels
FROM food.food_main_name
         JOIN food.food_name USING (food)
GROUP BY food_main_name.food, food_main_name.food_label;

alter table food_name_human
    owner to mb;

