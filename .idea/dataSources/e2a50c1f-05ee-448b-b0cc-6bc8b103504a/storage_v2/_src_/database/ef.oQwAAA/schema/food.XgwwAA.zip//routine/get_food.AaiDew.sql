create function get_food(gen.label_t) returns bigint
    stable
    strict
    language sql
as
$$
SELECT food FROM food_name WHERE food_label = $1
$$;

alter function get_food(gen.label_t) owner to mb;

