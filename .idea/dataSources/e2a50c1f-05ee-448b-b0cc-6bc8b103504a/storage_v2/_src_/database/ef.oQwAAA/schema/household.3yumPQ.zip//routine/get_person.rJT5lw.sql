create function get_person(bigint) returns text
    stable
    strict
    SET search_path = household, recipe, food, diet, gen
    language sql
as
$$
SELECT person_name FROM person WHERE person = $1
$$;

alter function get_person(bigint) owner to mb;

