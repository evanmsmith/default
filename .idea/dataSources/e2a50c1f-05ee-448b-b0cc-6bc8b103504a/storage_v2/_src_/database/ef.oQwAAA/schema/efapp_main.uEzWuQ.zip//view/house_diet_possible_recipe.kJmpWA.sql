create view house_diet_possible_recipe
            (house, rec, food_pref, foods_total, num_present, num_missing, present_foods, missing_foods) as
SELECT inventory.house,
       possible_recipe.rec,
       house_recipe_diet_sum.food_pref,
       house_recipe_diet_sum.foods_total,
       possible_recipe.num_present,
       possible_recipe.num_missing,
       possible_recipe.present_foods,
       possible_recipe.missing_foods
FROM household.inventory
         JOIN household.possible_recipe USING (inv)
         JOIN household.house_recipe_diet_sum USING (house, rec)
WHERE house_recipe_diet_sum.tolerated
ORDER BY ((house_recipe_diet_sum.food_pref).preference) DESC;

alter table house_diet_possible_recipe
    owner to mb;

