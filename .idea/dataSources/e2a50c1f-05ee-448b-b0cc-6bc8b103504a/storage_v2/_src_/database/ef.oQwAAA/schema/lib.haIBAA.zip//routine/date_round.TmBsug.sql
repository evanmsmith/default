create function date_round(base_date timestamp with time zone, round_interval interval) returns timestamp with time zone
    stable
    language sql
as
$$
SELECT TO_TIMESTAMP((EXTRACT(epoch FROM $1)::INTEGER + EXTRACT(epoch FROM $2)::INTEGER / 2)
                / EXTRACT(epoch FROM $2)::INTEGER * EXTRACT(epoch FROM $2)::INTEGER)
$$;

alter function date_round(timestamp with time zone, interval) owner to mb;

