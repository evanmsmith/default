create function get_std_diet(_class gen.label_t, _label gen.label_t) returns bigint
    stable
    strict
    language sql
as
$$
SELECT diet
 FROM
  diet
  JOIN diet_class USING (diet_class)
  JOIN std_diet USING (diet)
 WHERE diet_class = _class AND diet_label = _label;
$$;

alter function get_std_diet(gen.label_t, gen.label_t) owner to mb;

