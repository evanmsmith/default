create function match_ingr_to_food(text)
    returns TABLE(food bigint, confidence real)
    stable
    strict
    language sql
as
$$
SELECT
  food,
  (1 - dist)::real confidence
 FROM
 (
  SELECT
   food,
   ($1 <-> food_label_lemma) dist
  FROM
   food_name
  WHERE $1 <-> food_label_lemma < 0.9
  ORDER BY dist
  LIMIT 8
 ) a
 ;
$$;

alter function match_ingr_to_food(text) owner to mb;

