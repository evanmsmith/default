create view food_ont_class_human(food, food_ont_label, food_class) as
SELECT food_class.food,
       food_ont.food_ont_label,
       food_class.food_class
FROM food.food_class
         JOIN food.food_ont USING (food_ont);

alter table food_ont_class_human
    owner to mb;

