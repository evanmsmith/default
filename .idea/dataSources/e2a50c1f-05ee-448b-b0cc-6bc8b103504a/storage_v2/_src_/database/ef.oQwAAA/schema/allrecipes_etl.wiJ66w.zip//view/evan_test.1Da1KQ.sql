create view "evan test"
            (id, title, author__c, source_url__c, average_rating__c, number_of_reviews, created_at, updated_at,
             description, cooking_time__c, prep_time, additional, total_time, navigation_level, yield__c, servings,
             partner_tip, cooks_note, ingredients__c, directions__c, scraped, number_of_ratings)
as
SELECT allrecipes_in.id,
       allrecipes_in.title,
       allrecipes_in.author__c,
       allrecipes_in.source_url__c,
       allrecipes_in.average_rating__c,
       allrecipes_in.number_of_reviews,
       allrecipes_in.created_at,
       allrecipes_in.updated_at,
       allrecipes_in.description,
       allrecipes_in.cooking_time__c,
       allrecipes_in.prep_time,
       allrecipes_in.additional,
       allrecipes_in.total_time,
       allrecipes_in.navigation_level,
       allrecipes_in.yield__c,
       allrecipes_in.servings,
       allrecipes_in.partner_tip,
       allrecipes_in.cooks_note,
       allrecipes_in.ingredients__c,
       allrecipes_in.directions__c,
       allrecipes_in.scraped,
       allrecipes_in.number_of_ratings
FROM allrecipes_etl.allrecipes_in
WHERE allrecipes_in.number_of_ratings IS NOT NULL
ORDER BY allrecipes_in.number_of_ratings DESC, allrecipes_in.id DESC
LIMIT 10;

alter table "evan test"
    owner to mbtemp;

