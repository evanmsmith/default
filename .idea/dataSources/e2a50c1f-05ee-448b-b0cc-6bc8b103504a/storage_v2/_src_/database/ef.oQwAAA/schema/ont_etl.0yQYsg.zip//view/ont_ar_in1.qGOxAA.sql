create view ont_ar_in1 (nav3, nav4, nav5, nav6, nav7, num_recipes, ont3, ont4, ont5, ont6, ont7, ont_etl_note) as
SELECT ont_ar_src."nav-level 3"         AS nav3,
       ont_ar_src."nav-level 4"         AS nav4,
       ont_ar_src."nev-level 5"         AS nav5,
       ont_ar_src."nav-level 6"         AS nav6,
       ont_ar_src."nav-level 7"         AS nav7,
       ont_ar_src."COUNTA of Recipe ID" AS num_recipes,
       ont_ar_src."ontology of level 3" AS ont3,
       ont_ar_src."ontology of level 4" AS ont4,
       ont_ar_src."ontology of level 5" AS ont5,
       ont_ar_src."ontology of level 6" AS ont6,
       ont_ar_src."ontology of level 7" AS ont7,
       ont_ar_src."Notes"               AS ont_etl_note
FROM ont_etl.ont_ar_src;

alter table ont_ar_in1
    owner to mb;

