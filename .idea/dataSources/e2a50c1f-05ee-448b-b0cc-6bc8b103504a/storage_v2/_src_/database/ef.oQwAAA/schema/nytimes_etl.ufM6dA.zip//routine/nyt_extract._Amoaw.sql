create function nyt_extract(start integer, num integer, min_rating integer)
    returns TABLE(bom food_etl.recipe_bom_info_t[], backref text, title text, tag text[], rating double precision, num_ratings integer)
    stable
    strict
    language sql
as
$$
SELECT
  ARRAY(
   SELECT
    match
   FROM
    ingr_text_to_lines(ingredients, '^- (.*)$', '^For the (.*):$') lines
    JOIN LATERAL match_bom_line_simple(parse_bom_line_simple(lines)) match
     ON true
  ) bom,
  source_url,
  title,
  ARRAY(
   SELECT DISTINCT unnest
   FROM
    unnest(
     regexp_split_to_array(tags, ',') ||
      regexp_split_to_array(feature_tags, 'dummy')
    )
  ) tag,
  1.0 * rating_value::float / 5,
  rating::integer
 FROM
  (
   SELECT * FROM nytimes_etl.ny_in
   WHERE
    rating_value IS NOT NULL AND rating_value != '' AND
    rating_value::integer >= min_rating
   LIMIT num OFFSET start
  ) ny_in
 ;
$$;

alter function nyt_extract(integer, integer, integer) owner to mb;

