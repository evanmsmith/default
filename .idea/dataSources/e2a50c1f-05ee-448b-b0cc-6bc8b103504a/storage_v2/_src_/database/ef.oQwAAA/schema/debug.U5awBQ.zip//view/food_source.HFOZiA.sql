create view food_source(food, food_label, src, usage) as
SELECT food.food,
       food.food_label,
       CASE
           WHEN spn_food.spn_id IS NOT NULL THEN 'spn'::text
           WHEN fs_food.food IS NOT NULL THEN 'fs'::text
           ELSE 'unknown'::text
           END                                  AS src,
       (SELECT count(*) AS count
        FROM recipe.bom_det
        WHERE food.food = bom_det.food::bigint) AS usage
FROM food.food_main_name food
         LEFT JOIN spn_food_etl.spn_food USING (food)
         LEFT JOIN foodsubs_etl.fs_food USING (food);

alter table food_source
    owner to mb;

