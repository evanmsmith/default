create view nyt_indata
            (rec, rec_label, source_url, author, cooking_time, title, tags, feature_tags, yield, recipe_story, image,
             rating, rating_value, ingredients, preparation, comments)
as
SELECT recipe.rec,
       recipe.rec_label,
       ny_in.source_url,
       ny_in.author,
       ny_in.cooking_time,
       ny_in.title,
       ny_in.tags,
       ny_in.feature_tags,
       ny_in.yield,
       ny_in.recipe_story,
       ny_in.image,
       ny_in.rating,
       ny_in.rating_value,
       ny_in.ingredients,
       ny_in.preparation,
       ny_in.comments
FROM recipe.recipe
         JOIN food_etl.etl_recipe USING (rec)
         JOIN nytimes_etl.ny_in ON etl_recipe.backref = ny_in.source_url;

alter table nyt_indata
    owner to mb;

