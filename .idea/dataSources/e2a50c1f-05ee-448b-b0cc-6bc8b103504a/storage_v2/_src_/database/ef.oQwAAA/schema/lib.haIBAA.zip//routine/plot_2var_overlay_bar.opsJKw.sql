create function plot_2var_overlay_bar(val double precision[], max double precision, width integer, chr character[]) returns text
    immutable
    language sql
as
$$
    -- Plot two values, which must range from 0 to max, width characters
 -- wide, using chr's as plot characters. The first value is primary,
 -- with the 2nd overlayed (NOT STACKED) on it.
 WITH dim AS (
  SELECT
   round(val[1] / max * width)::integer AS barsize1,
   round(val[2] / max * width)::integer AS barsize2
 )
 SELECT
  '|' ||
  repeat(
   chr[2],
   barsize2
  ) ||
  repeat(
   chr[1],
   barsize1 - barsize2
  ) ||
  repeat(
   ' ',
   width - barsize1
  ) || '|'
 FROM
  dim
 ;
$$;

alter function plot_2var_overlay_bar(double precision[], double precision, integer, character[]) owner to mb;

