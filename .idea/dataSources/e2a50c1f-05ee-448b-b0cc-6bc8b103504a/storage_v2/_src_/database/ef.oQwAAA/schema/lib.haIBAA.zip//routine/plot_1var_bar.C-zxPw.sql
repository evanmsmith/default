create function plot_1var_bar(val double precision, max double precision, width integer, chr character) returns text
    immutable
    language sql
as
$$
    -- Plot one value, which must range from 0 to max, width characters wide,
 -- using chr as plot character
 WITH dim AS (
  SELECT
   round(1.0 * val / max * width)::integer AS barsize
 )
 SELECT
  '|' ||
  repeat(
   chr,
   barsize
  ) ||
  repeat(
   ' ',
   width - barsize
  ) || '|'
 FROM
  dim
 ;
$$;

alter function plot_1var_bar(double precision, double precision, integer, char) owner to mb;

