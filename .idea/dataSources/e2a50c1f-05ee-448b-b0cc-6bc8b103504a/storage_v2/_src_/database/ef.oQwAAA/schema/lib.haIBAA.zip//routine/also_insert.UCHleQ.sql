create function also_insert() returns trigger
    language plpgsql
as
$$
BEGIN
 -- $1 table to insert
 -- $2 column to copy from trigger
 EXECUTE 'INSERT INTO '||TG_ARGV[0]||'('||TG_ARGV[1]||') (SELECT $1.'||TG_ARGV[1]||')' USING NEW;

 RETURN NEW;
END;
$$;

alter function also_insert() owner to mb;

