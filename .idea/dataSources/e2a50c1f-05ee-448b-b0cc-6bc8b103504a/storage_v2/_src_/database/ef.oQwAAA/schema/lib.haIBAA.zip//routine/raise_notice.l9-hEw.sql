create function raise_notice(_text text) returns void
    language plpgsql
as
$$
BEGIN
 RAISE NOTICE '%', $1;
END;
$$;

alter function raise_notice(text) owner to mb;

