create function tsv_stem_word(_dict regconfig, _string text) returns text
    immutable
    strict
    language sql
as
$$
SELECT coalesce(lexeme, $2)
 FROM unnest(to_tsvector($1, $2)) arr
 ;
$$;

alter function tsv_stem_word(regconfig, text) owner to mb;

