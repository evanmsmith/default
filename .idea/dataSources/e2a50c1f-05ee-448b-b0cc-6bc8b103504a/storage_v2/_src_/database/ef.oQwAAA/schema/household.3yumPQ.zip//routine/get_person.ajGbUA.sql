create function get_person(text) returns bigint
    stable
    strict
    SET search_path = household, recipe, food, diet, gen
    language sql
as
$$
SELECT person FROM person WHERE person_name = $1
$$;

alter function get_person(text) owner to mb;

