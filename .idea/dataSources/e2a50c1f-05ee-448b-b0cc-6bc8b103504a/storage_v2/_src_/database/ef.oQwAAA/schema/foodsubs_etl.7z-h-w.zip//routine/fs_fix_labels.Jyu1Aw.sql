create function fs_fix_labels(text) returns text
    immutable
    strict
    SET search_path = foodsubs_etl, gspread_src, food, gen, lib
    language sql
as
$$
    -- Fix quoting from ' to ". (Except when it is already "!) Also deal
 -- with literal ' characters in the text.
 WITH
 fix_quoting AS (
  SELECT
   translate_string($1,
    array[
     '[''', '["',
     ''']', '"]',
     ''',', '",',
     ', ''', ', "'
    ]
   ) s
 ),
 -- Fix double quotes within double-quoted strings.
 fix_inline_quotes AS (
  SELECT
   regexp_replace(s,
    '(?<!, |[[])(")([^],])', '\\"\2', 'g'
   ) s
  FROM fix_quoting
 ),
 -- 
 fix_escaped_quotes AS (
  SELECT replace(s, '\''', '''') s FROM fix_inline_quotes
 ),
 -- Fix instances of \xNN:
 --
 -- \x92 -> '
 -- \x97 -> --
 fix_x AS (
  SELECT translate_string(s, array['\x92', '''', '\x97', '--']) s
  FROM fix_escaped_quotes
 )
 -- Select result with all fixes applied.
 SELECT s FROM fix_x
 ;
$$;

alter function fs_fix_labels(text) owner to mb;

