create function get_food_ont(gen.label_t) returns bigint
    stable
    strict
    language sql
as
$$
SELECT food_ont FROM food_ont WHERE food_ont_label = $1
$$;

alter function get_food_ont(gen.label_t) owner to mb;

