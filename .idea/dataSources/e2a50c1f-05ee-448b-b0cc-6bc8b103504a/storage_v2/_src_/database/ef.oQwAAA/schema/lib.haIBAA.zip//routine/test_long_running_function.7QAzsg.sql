create function test_long_running_function() returns text
    language plpgsql
as
$$
BEGIN
 PERFORM pg_sleep(5);
 RAISE WARNING 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';
 RETURN clock_timestamp();
END
$$;

alter function test_long_running_function() owner to mb;

