create function etl_recipe_bom_simple(bom food_etl.recipe_bom_info_t[], source text, backref text, title text, ont food_etl.rec_ont_info_t[], _rating double precision, _num_ratings integer) returns bigint
    strict
    SET search_path = food_etl, lang, food, recipe, gen
    language sql
as
$$
WITH rec AS (
  SELECT etl_recipe(source, backref, title) rec
 ),
 rating AS (
  INSERT INTO recipe_rating SELECT rec, _rating, _num_ratings FROM rec
 ),
 ont AS (
  INSERT INTO rec_class
  SELECT
   rec, rec_ont, rec_class, rec_class_note
  FROM rec, unnest(ont)
 )
 INSERT INTO etl_det SELECT rec, bom_det_in.*
 FROM rec, unnest(bom) bom_det_in
 RETURNING rec
 ;
$$;

alter function etl_recipe_bom_simple(food_etl.recipe_bom_info_t[], text, text, text, food_etl.rec_ont_info_t[], double precision, integer) owner to mb;

