create function get_rec_ont(bigint) returns gen.label_t
    stable
    strict
    language sql
as
$$
SELECT rec_ont_label FROM rec_ont WHERE rec_ont = $1
$$;

alter function get_rec_ont(bigint) owner to mb;

