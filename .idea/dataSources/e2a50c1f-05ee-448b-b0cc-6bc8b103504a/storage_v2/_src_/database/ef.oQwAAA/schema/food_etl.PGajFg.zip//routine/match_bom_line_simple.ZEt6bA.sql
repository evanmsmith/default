create function match_bom_line_simple(ingr food_etl.recipe_bom_info_t) returns food_etl.recipe_bom_info_t
    stable
    strict
    language sql
as
$$
SELECT
  lineno,
  section,
  orig_text,
  food_descr,
  qty_descr,
  match.food::food_t,
  (bom.confidence * match.confidence)::numeric(3,2)::real confidence,
  'machine'::bom_origin_t,
  ''::note_t,
  metadata
 FROM
  (SELECT $1.*) bom
  LEFT JOIN LATERAL match_ingr_to_food_one(food_descr) match ON true
 ;
$$;

alter function match_bom_line_simple(food_etl.recipe_bom_info_t) owner to mb;

