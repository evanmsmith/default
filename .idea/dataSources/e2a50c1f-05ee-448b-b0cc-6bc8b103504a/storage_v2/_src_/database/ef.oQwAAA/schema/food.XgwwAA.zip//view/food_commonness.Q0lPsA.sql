create view food_commonness(food, initcap, string_agg, counter, z_score, in_pantry) as
SELECT f.food,
       initcap(fn.food_label::text)                                 AS initcap,
       string_agg(DISTINCT initcap(fc.food_class::text), ','::text) AS string_agg,
       CASE
           WHEN count(e."Food") > 0 THEN count(f.food) / count(DISTINCT fc.food_class)
           ELSE 0::bigint
           END                                                      AS counter,
       CASE
           WHEN count(e."Food") > 0 THEN
                   ((count(f.food) / count(DISTINCT fc.food_class))::numeric - ((SELECT avg(table1.r) AS avg
                                                                                 FROM (SELECT CASE
                                                                                                  WHEN count(e_1."Food") > 0
                                                                                                      THEN count(f_1.food) / count(DISTINCT fc_1.food_class)
                                                                                                  ELSE 0::bigint
                                                                                                  END AS r
                                                                                       FROM food.food f_1
                                                                                                JOIN food.food_name fn_1 ON fn_1.food = f_1.food
                                                                                                JOIN food.food_ont_class_human fc_1 ON fc_1.food = fn_1.food
                                                                                                LEFT JOIN efapp_main.efapp_recipe_ingredients e_1
                                                                                                          ON initcap(e_1."Food"::text) = initcap(fn_1.food_label::text)
                                                                                                LEFT JOIN household.item hi_1 ON hi_1.food::bigint = f_1.food
                                                                                       GROUP BY f_1.food, (initcap(fn_1.food_label::text)), hi_1.inv) table1))) /
                   ((SELECT stddev_pop(table1.r) AS stddev_pop
                     FROM (SELECT CASE
                                      WHEN count(e_1."Food") > 0 THEN count(f_1.food) / count(DISTINCT fc_1.food_class)
                                      ELSE 0::bigint
                                      END AS r
                           FROM food.food f_1
                                    JOIN food.food_name fn_1 ON fn_1.food = f_1.food
                                    JOIN food.food_ont_class_human fc_1 ON fc_1.food = fn_1.food
                                    LEFT JOIN efapp_main.efapp_recipe_ingredients e_1
                                              ON initcap(e_1."Food"::text) = initcap(fn_1.food_label::text)
                                    LEFT JOIN household.item hi_1 ON hi_1.food::bigint = f_1.food
                           GROUP BY f_1.food, (initcap(fn_1.food_label::text)), hi_1.inv) table1))
           ELSE 0::numeric
           END                                                      AS z_score,
       CASE
           WHEN hi.inv = 1 THEN 'Yes'::text
           ELSE 'No'::text
           END                                                      AS in_pantry
FROM food.food f
         JOIN food.food_name fn ON fn.food = f.food
         JOIN food.food_ont_class_human fc ON fc.food = fn.food
         LEFT JOIN efapp_main.efapp_recipe_ingredients e ON initcap(e."Food"::text) = initcap(fn.food_label::text)
         LEFT JOIN household.item hi ON hi.food::bigint = f.food
GROUP BY f.food, (initcap(fn.food_label::text)), hi.inv;

alter table food_commonness
    owner to mbtemp;

