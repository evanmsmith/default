create function base36_decode(base36 character varying) returns bigint
    immutable
    language plpgsql
as
$$
DECLARE
   a char[];
   ret bigint;
   i int;
   val int;
   chars varchar;
  BEGIN
  chars := '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  FOR i IN REVERSE char_length(base36)..1 LOOP
   a := a || substring(upper(base36) FROM i FOR 1)::char;
  END LOOP;
  i := 0;
  ret := 0;
  WHILE i < (array_length(a,1)) LOOP
   val := position(a[i+1] IN chars)-1;
   ret := ret + (val * (36 ^ i));
   i := i + 1;
  END LOOP;
  RETURN ret;
END;
$$;

alter function base36_decode(varchar) owner to mb;

