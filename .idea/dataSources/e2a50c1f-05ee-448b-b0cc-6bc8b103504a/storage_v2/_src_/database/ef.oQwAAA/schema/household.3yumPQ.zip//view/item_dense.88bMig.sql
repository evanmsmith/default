create view item_dense(inv, food, inv_qty) as
SELECT inventory.inv,
       food.food::food.food_t                                       AS food,
       COALESCE(item.inv_qty::numeric, 0::numeric)::food.food_qty_t AS inv_qty
FROM household.inventory
         CROSS JOIN food.food
         LEFT JOIN household.item USING (inv, food);

alter table item_dense
    owner to mb;

