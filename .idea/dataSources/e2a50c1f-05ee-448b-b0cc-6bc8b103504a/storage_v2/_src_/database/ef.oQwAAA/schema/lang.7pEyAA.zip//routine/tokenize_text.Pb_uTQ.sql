create function tokenize_text(text) returns SETOF lang.token_t
    immutable
    strict
    language sql
as
$$
SELECT
  lexeme::text,
  (
   CASE
    WHEN punctuation_p(lexeme) THEN 'punctuation'
    WHEN num_frac_p(lexeme) THEN 'number'
    ELSE 'word'
   END
  )::token_kind_t kind,
  -- coalesce to avoid stopping behavior of tsv processing, since
  -- normally-stopped words such as conjunctions can be useful. But
  -- convey whether it would have been a stop.
  coalesce(tsv_stem_word('english', lexeme), lexeme) lemma,
  ARRAY(SELECT lang_get_part(coalesce(tsv_stem_word('english', lexeme), lexeme))) part,
  tsv_stem_word('english', lexeme) IS NULL stop,
  pos::integer
 FROM
  unnest(regexp_split_to_array(trim($1), '[\s,;/]+'))
   WITH ORDINALITY toks(lexeme, pos)
 ;
$$;

alter function tokenize_text(text) owner to mb;

