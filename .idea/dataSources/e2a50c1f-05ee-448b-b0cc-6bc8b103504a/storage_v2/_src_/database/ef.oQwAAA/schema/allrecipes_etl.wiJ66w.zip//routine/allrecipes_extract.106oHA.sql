create function allrecipes_extract(start integer, num integer, min_rating integer)
    returns TABLE(bom food_etl.recipe_bom_info_t[], backref text, title text, nav text[], rating double precision, num_ratings integer)
    stable
    strict
    language sql
as
$$
SELECT
  ARRAY(
   SELECT
    match
   FROM
    (
     SELECT
      null::text section,
      ingr_line,
      lineno::integer
     FROM
      jsonb_array_elements_text(ingredients__c) WITH ORDINALITY
       lines(ingr_line, lineno)
     WHERE ingr_line != '' AND ingr_line != 'Add all ingredients to list'
    ) lines
    JOIN LATERAL match_bom_line_simple(parse_bom_line_simple(lines)) match
     ON true
  ) bom,
  source_url__c,
  title,
  ARRAY(SELECT jsonb_array_elements_text(navigation_level)) nav,
  1.0 * average_rating__c::float / 5 rating,
  number_of_ratings num_ratings
 FROM
  (
   SELECT * FROM allrecipes_etl.allrecipes_in
   WHERE
    average_rating__c IS NOT NULL AND average_rating__c::integer >= min_rating
   LIMIT num OFFSET start
  ) all_in
 ;
$$;

alter function allrecipes_extract(integer, integer, integer) owner to mb;

