create view rec_ont_class_human(rec, rec_ont_label, rec_class, rec_class_note) as
SELECT rec_class.rec,
       rec_ont.rec_ont_label,
       rec_class.rec_class,
       rec_class.rec_class_note
FROM recipe.rec_class
         JOIN recipe.rec_ont USING (rec_ont);

alter table rec_ont_class_human
    owner to mb;

