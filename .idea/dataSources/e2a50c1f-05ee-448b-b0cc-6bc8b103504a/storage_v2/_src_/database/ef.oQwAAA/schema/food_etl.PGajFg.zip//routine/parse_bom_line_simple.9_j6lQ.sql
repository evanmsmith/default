create function parse_bom_line_simple(ingr_line food_etl.ingr_line_t) returns food_etl.recipe_bom_info_t
    immutable
    strict
    language sql
as
$$
SELECT
  lineno,
  section,
  orig_text,
  food_descr,
  qty_descr,
  NULL::food_t,
  confidence,
  'machine'::bom_origin_t,
  ''::note_t,
  metadata
 FROM
  (SELECT $1.*) il
  JOIN LATERAL parse_bom_text_simple(ingr_line) ON true
 ;
$$;

alter function parse_bom_line_simple(food_etl.ingr_line_t) owner to mb;

