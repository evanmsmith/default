create function grant_all_in_current_schema() returns void
    language plpgsql
as
$$
BEGIN
 EXECUTE 'GRANT USAGE ON SCHEMA ' || current_schema || ' TO ' || current_schema;
 EXECUTE 'GRANT ALL ON ALL TABLES IN SCHEMA '
 || current_schema
 || ' TO '
 || ' '
 || current_schema;
 EXECUTE 'GRANT USAGE ON ALL SEQUENCES IN SCHEMA '
 || current_schema
 || ' TO '
 || ' '
 || current_schema;
 EXECUTE 'GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA '
 || current_schema
 || ' TO '
 || ' '
 || current_schema;
END
$$;

alter function grant_all_in_current_schema() owner to mb;

