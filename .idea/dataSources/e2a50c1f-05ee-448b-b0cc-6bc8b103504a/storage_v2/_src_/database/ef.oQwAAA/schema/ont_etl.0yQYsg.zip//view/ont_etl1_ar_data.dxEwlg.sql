create view ont_etl1_ar_data(dat) as
SELECT DISTINCT ON (ont_ar_in2.cl, ont_ar_in2.ont) ROW (ont_ar_in2.cl::recipe.rec_class_t, 'nav'::text::gen.label_t, ('nav-level '::text || ont_ar_in2.lv)::gen.note_t, ont_ar_in2.ont::gen.label_t, ont_ar_in2.ont_etl_note::gen.note_t, ont_ar_in2.lv::text)::ont_etl.ont_etl1_row1_t AS dat
FROM ont_etl.ont_ar_in2
WHERE (ont_ar_in2.ont::text <> ALL
       (ARRAY [''::character varying, '****'::character varying, 'NULL'::character varying]::text[]))
  AND ont_ar_in2.ont::text !~~ '%**%'::text;

alter table ont_etl1_ar_data
    owner to mb;

