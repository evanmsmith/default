create function add_bom_det_human(_rec_label gen.label_t, _food_label gen.label_t, _bom_qty numeric) returns void
    strict
    language sql
as
$$
INSERT INTO bom_det SELECT
  get_rec(_rec_label),
  get_food(_food_label),
  _bom_qty
 ;
$$;

alter function add_bom_det_human(gen.label_t, gen.label_t, numeric) owner to mb;

