create function etl_fs_foods(start integer, num integer) returns void
    strict
    SET search_path = foodsubs_etl, gspread_src, food, gen, lib
    language sql
as
$$
SELECT
  etl_foodsubs_food(foodsubs_foods)
 FROM
  foodsubs_foods
 OFFSET start LIMIT num
 ;
$$;

alter function etl_fs_foods(integer, integer) owner to mb;

