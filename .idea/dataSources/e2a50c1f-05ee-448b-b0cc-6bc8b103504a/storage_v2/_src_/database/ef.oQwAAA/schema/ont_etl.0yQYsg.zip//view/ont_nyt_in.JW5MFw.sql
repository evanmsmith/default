create view ont_nyt_in(tag, ont, ont_etl_note) as
SELECT ont_nyt_src."Class aka TAGS" AS tag,
       ont_nyt_src."Ontology"       AS ont,
       ont_nyt_src."Comments"       AS ont_etl_note
FROM ont_etl.ont_nyt_src;

alter table ont_nyt_in
    owner to mb;

