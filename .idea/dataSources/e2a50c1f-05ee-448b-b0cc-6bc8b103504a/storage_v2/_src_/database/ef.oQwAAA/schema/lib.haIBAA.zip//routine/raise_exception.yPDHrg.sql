create function raise_exception(_text text) returns void
    language plpgsql
as
$$
BEGIN
 RAISE EXCEPTION '%', $1;
END;
$$;

alter function raise_exception(text) owner to mb;

