create function translate_string(text, text[]) returns text
    immutable
    strict
    language sql
as
$$
WITH RECURSIVE r AS (
  SELECT
   $1 s,
   $2 tr
  UNION ALL
  SELECT
   replace(s, tr[1], tr[2]) s,
   tr[3:array_length(tr, 1)] tr
  FROM r
  WHERE array_length(tr, 1) > 0
 )
 SELECT s FROM r WHERE tr = array[]::text[]
 ;
$$;

alter function translate_string(text, text[]) owner to mb;

