create view possible_recipe (rec, inv, sufficient, num_present, num_missing, present_foods, missing_foods) as
SELECT possible_recipe_bom.rec,
       possible_recipe_bom.inv,
       bool_and(possible_recipe_bom.sufficient)                                          AS sufficient,
       sum(
               CASE
                   WHEN possible_recipe_bom.sufficient THEN 1
                   ELSE 0
                   END)                                                                  AS num_present,
       sum(
               CASE
                   WHEN NOT possible_recipe_bom.sufficient THEN 1
                   ELSE 0
                   END)                                                                  AS num_missing,
       array_remove(array_agg((SELECT food.food
                               FROM food.food
                               WHERE food.food = possible_recipe_bom.food::bigint
                                 AND possible_recipe_bom.sufficient)), NULL::bigint)     AS present_foods,
       array_remove(array_agg((SELECT food.food
                               FROM food.food
                               WHERE food.food = possible_recipe_bom.food::bigint
                                 AND NOT possible_recipe_bom.sufficient)), NULL::bigint) AS missing_foods
FROM household.possible_recipe_bom
GROUP BY possible_recipe_bom.rec, possible_recipe_bom.inv;

alter table possible_recipe
    owner to mb;

