create view fs_indata
            (food, food_label, labels, possible_names, url, page_hierarchy1, page_hierarchy2, page_hierarchy3,
             page_hierarchy4, substitutes, notes, to_make, pronunciation, shopping_hints, equivalents, complements,
             tips, cooking_hints, where_to_find, valid)
as
SELECT food.food,
       fs_food.food_main_name AS food_label,
       fsr_fixed.labels,
       fsr_fixed.possible_names,
       fsr_fixed.url,
       fsr_fixed.page_hierarchy1,
       fsr_fixed.page_hierarchy2,
       fsr_fixed.page_hierarchy3,
       fsr_fixed.page_hierarchy4,
       fsr_fixed.substitutes,
       fsr_fixed.notes,
       fsr_fixed.to_make,
       fsr_fixed.pronunciation,
       fsr_fixed.shopping_hints,
       fsr_fixed.equivalents,
       fsr_fixed.complements,
       fsr_fixed.tips,
       fsr_fixed.cooking_hints,
       fsr_fixed.where_to_find,
       fsr_fixed.valid
FROM food.food
         JOIN foodsubs_etl.fs_food USING (food)
         JOIN (SELECT ARRAY(SELECT jsonb_array_elements_text(
                                           foodsubs_etl.fs_fix_labels(foodsubs_foods_raw.possible_names)::jsonb) AS jsonb_array_elements_text) AS labels,
                      foodsubs_foods_raw.possible_names,
                      foodsubs_foods_raw.url,
                      foodsubs_foods_raw.page_hierarchy1,
                      foodsubs_foods_raw.page_hierarchy2,
                      foodsubs_foods_raw.page_hierarchy3,
                      foodsubs_foods_raw.page_hierarchy4,
                      foodsubs_foods_raw.substitutes,
                      foodsubs_foods_raw.notes,
                      foodsubs_foods_raw.to_make,
                      foodsubs_foods_raw.pronunciation,
                      foodsubs_foods_raw.shopping_hints,
                      foodsubs_foods_raw.equivalents,
                      foodsubs_foods_raw.complements,
                      foodsubs_foods_raw.tips,
                      foodsubs_foods_raw.cooking_hints,
                      foodsubs_foods_raw.where_to_find,
                      foodsubs_foods_raw.valid
               FROM foodsubs_etl.foodsubs_foods_raw) fsr_fixed ON fs_food.food_main_name = fsr_fixed.labels[1];

alter table fs_indata
    owner to mb;

