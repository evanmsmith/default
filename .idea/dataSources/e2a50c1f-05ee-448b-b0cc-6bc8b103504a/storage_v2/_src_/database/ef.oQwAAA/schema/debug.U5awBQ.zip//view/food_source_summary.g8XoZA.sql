create view food_source_summary(src, count) as
SELECT food_source.src,
       count(*) AS count
FROM debug.food_source
GROUP BY food_source.src
ORDER BY food_source.src
LIMIT 20;

alter table food_source_summary
    owner to mb;

