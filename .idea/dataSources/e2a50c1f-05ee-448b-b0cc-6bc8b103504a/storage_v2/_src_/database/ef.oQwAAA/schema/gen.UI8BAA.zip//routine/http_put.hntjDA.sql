create function http_put(uri character varying, content character varying, content_type character varying) returns gen.http_response
    language sql
as
$$
SELECT http(('PUT', $1, NULL, $3, $2)::http_request)
$$;

alter function http_put(varchar, varchar, varchar) owner to mb;

