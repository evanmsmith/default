create function etl_recipe(_source text, _backref text, _label text) returns bigint
    strict
    language sql
as
$$
WITH r AS (
  INSERT INTO recipe (rec_label) VALUES (_label) RETURNING rec
 )
 INSERT INTO etl_recipe SELECT rec, _source FROM r RETURNING rec
 ;
$$;

alter function etl_recipe(text, text, text) owner to mb;

