create function etl_spn_food_subs(ingr_id integer)
    returns TABLE(spn_id integer, food_id integer, subs_id integer, food_subs_component_id integer)
    strict
    SET search_path = spn_subs_etl, spn_food_etl, spn_etl, food, gen
    language sql
as
$$
/* 
TODO
- Add check if any substution food do not have a ID on our database
*/
    WITH
    spn_subs_response AS (
        SELECT * FROM spn_ingr_sub($1)
        -- Hope it ignores a null table
        WHERE spn_id IS NOT NULL
        AND   subs_component_name IS NOT NULL
    ),
    id_original_food AS (
        SELECT      A.food,
        			B.food_name food_label
        FROM        spn_food_etl.spn_food A
        JOIN        spn_subs_response B
        ON          A.spn_id = B.spn_id
    ),
    unique_sub_component AS (
        SELECT DISTINCT subs_component_name food_label
        FROM            spn_subs_response
    ),
    ins_sub_component_food AS (
        INSERT INTO     food (food_label)
        SELECT          food_label
        FROM            unique_sub_component
        ON CONFLICT ON CONSTRAINT food_food_label_key DO UPDATE
        SET             food_label = EXCLUDED.food_label
        RETURNING       food, food_label
    ),
    spn_to_insert AS (
        SELECT      B.food food_id,
                    C.food food_subs_component_id,
                    spn_id,
                    subs_id,
                    subs_component_id,
                    food_name,
                    food_amount,
                    food_units,
                    subs_component_name,
                    subs_component_amount,
                    subs_component_units
        FROM        spn_subs_response A
        LEFT JOIN   id_original_food B
        ON          A.food_name = B.food_label
        LEFT JOIN   ins_sub_component_food C
        ON          A.subs_component_name = C.food_label
    ),
    ins_spn_food_subs AS (
        INSERT INTO spn_food_subs
        SELECT      *
        FROM        spn_to_insert
        ON CONFLICT ON CONSTRAINT spn_food_subs_pkey DO NOTHING
        RETURNING   spn_id, food_id, subs_id, food_subs_component_id
    )
    SELECT  spn_id::integer,
            food_id::integer,
            subs_id::integer,
            food_subs_component_id::integer
    FROM    ins_spn_food_subs
    ;
$$;

alter function etl_spn_food_subs(integer) owner to mbtemp;

