create view spn_top_ingr(ingr_name, spn_id) as
SELECT (regexp_split_to_array(regexp_split_to_table(data.content::text, '\n'::text), ';'::text))[1] AS ingr_name,
       (regexp_split_to_array(regexp_split_to_table(data.content::text, '\n'::text), ';'::text))[2] AS spn_id
FROM gen.http_get(
             'https://spoonacular.com/application/frontend/downloads/top-1k-ingredients.csv'::character varying) data(status, content_type, headers, content);

alter table spn_top_ingr
    owner to mb;

