create function food_name_calc_lemma() returns trigger
    stable
    SET search_path = food, lang, gen
    language plpgsql
as
$$
BEGIN
 NEW.food_label_lemma = (
  SELECT string_agg(lemma, ' ') FROM tokenize_text(NEW.food_label::text)
 );
 RETURN NEW;
END;
$$;

alter function food_name_calc_lemma() owner to mb;

