create function week_to_date(_year integer, _week integer, _dow integer) returns date
    immutable
    language sql
as
$$
    /*******************************************************************************
    Takes the day of the week (0 to 6 with 0 being Sunday), week of the year, and
    year. Returns the corresponding date.
    Created On: 2011-12-21
    Revised On: 2013-01-02
    Author: Chris West
    Reference: http://cwestblog.com/2011/12/21/postgresql-week-number-to-date/
    ******************************************************************************/
SELECT to_timestamp('1 ' || _year,'IW IYYY')::date + (COALESCE(_dow, 1) + 6 ) % 7 + 7 * (_week - 1);
$$;

alter function week_to_date(integer, integer, integer) owner to mb;

