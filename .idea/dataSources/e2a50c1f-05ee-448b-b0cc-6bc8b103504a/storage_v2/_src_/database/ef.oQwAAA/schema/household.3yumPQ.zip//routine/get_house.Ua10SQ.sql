create function get_house(gen.label_t) returns bigint
    stable
    strict
    SET search_path = household, recipe, food, diet, gen
    language sql
as
$$
SELECT house FROM house WHERE house_label = $1
$$;

alter function get_house(gen.label_t) owner to mb;

