create function http_head(uri character varying) returns gen.http_response
    language sql
as
$$
SELECT http(('HEAD', $1, NULL, NULL, NULL)::http_request)
$$;

alter function http_head(varchar) owner to mb;

