create function get_rec_ont(gen.label_t) returns bigint
    stable
    strict
    language sql
as
$$
SELECT rec_ont FROM rec_ont WHERE rec_ont_label = $1
$$;

alter function get_rec_ont(gen.label_t) owner to mb;

