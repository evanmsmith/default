create function ont_etl1_do_ar() returns void
    stable
    strict
    SET search_path = ont_etl, recipe, gen
    language sql
as
$$
SELECT
  ont_etl1_load1(dat, 'ar-nav')
 FROM
  ont_etl1_ar_data;
$$;

alter function ont_etl1_do_ar() owner to mb;

