create view ont_etl1_nyt_data(dat) as
SELECT ROW (ont_nyt_in.tag::recipe.rec_class_t, 'tag'::text::gen.label_t, NULL::text::gen.note_t, ont_nyt_in.ont::gen.label_t, ont_nyt_in.ont_etl_note::gen.note_t, NULL::text)::ont_etl.ont_etl1_row1_t AS dat
FROM ont_etl.ont_nyt_in;

alter table ont_etl1_nyt_data
    owner to mb;

