create function http_get(uri character varying) returns gen.http_response
    language sql
as
$$
SELECT http(('GET', $1, NULL, NULL, NULL)::http_request)
$$;

alter function http_get(varchar) owner to mb;

