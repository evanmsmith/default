create function add_item_human(_inv bigint, _food_label gen.label_t, _inv_qty numeric) returns void
    strict
    language sql
as
$$
INSERT INTO item SELECT _inv, get_food(_food_label), _inv_qty
  WHERE _inv_qty > 0;
$$;

alter function add_item_human(bigint, gen.label_t, numeric) owner to mb;

