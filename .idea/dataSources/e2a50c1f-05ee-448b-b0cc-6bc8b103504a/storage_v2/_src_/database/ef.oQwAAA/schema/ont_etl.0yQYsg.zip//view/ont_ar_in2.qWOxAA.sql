create view ont_ar_in2(cl, ont, ont_etl_note, lv) as
SELECT ont_ar_in1.nav3 AS cl,
       ont_ar_in1.ont3 AS ont,
       ont_ar_in1.ont_etl_note,
       3               AS lv
FROM ont_etl.ont_ar_in1
UNION ALL
SELECT ont_ar_in1.nav4 AS cl,
       ont_ar_in1.ont4 AS ont,
       ont_ar_in1.ont_etl_note,
       4               AS lv
FROM ont_etl.ont_ar_in1
UNION ALL
SELECT ont_ar_in1.nav5 AS cl,
       ont_ar_in1.ont5 AS ont,
       ont_ar_in1.ont_etl_note,
       5               AS lv
FROM ont_etl.ont_ar_in1
UNION ALL
SELECT ont_ar_in1.nav6 AS cl,
       ont_ar_in1.ont6 AS ont,
       ont_ar_in1.ont_etl_note,
       6               AS lv
FROM ont_etl.ont_ar_in1
UNION ALL
SELECT ont_ar_in1.nav7 AS cl,
       ont_ar_in1.ont7 AS ont,
       ont_ar_in1.ont_etl_note,
       7               AS lv
FROM ont_etl.ont_ar_in1;

alter table ont_ar_in2
    owner to mb;

