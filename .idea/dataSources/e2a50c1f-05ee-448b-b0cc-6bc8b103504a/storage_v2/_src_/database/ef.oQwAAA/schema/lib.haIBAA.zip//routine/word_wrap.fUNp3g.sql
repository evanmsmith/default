create function word_wrap(line text, linelen integer) returns SETOF text
    immutable
    language plpgsql
as
$$
DECLARE
  words text[] := string_to_array(line,' ');
  i integer;
  res text:='';
BEGIN
  if trim(line)='' then
    return next '';
    return;
    end if;
 for i IN 1 .. array_upper(words,1) LOOP
   if length(res)+length(words[i]) > linelen THEN
     return next res;
     res := '';
     END IF ;
   if res<>'' then
     res := res || ' ';
     end if;
   res := res || words[i];
   end loop;
return next res;
END
$$;

alter function word_wrap(text, integer) owner to mb;

