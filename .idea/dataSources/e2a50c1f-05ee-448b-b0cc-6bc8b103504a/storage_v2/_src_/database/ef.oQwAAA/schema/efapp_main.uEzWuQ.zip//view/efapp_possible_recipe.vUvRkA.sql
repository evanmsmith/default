create view efapp_possible_recipe(house, house_label, inv, rec, rec_label) as
SELECT house.house,
       house.house_label,
       inventory.inv,
       possible_recipe.rec,
       recipe.rec_label
FROM household.house
         JOIN household.inventory USING (house)
         JOIN household.possible_recipe USING (inv)
         JOIN recipe.recipe USING (rec)
WHERE possible_recipe.sufficient;

alter table efapp_possible_recipe
    owner to mb;

