create view rec_ont_usage(rec_ont_label, count) as
SELECT rec_ont.rec_ont_label,
       count(*) AS count
FROM recipe.rec_ont
         JOIN recipe.rec_class USING (rec_ont)
GROUP BY rec_ont.rec_ont_label;

alter table rec_ont_usage
    owner to mb;

