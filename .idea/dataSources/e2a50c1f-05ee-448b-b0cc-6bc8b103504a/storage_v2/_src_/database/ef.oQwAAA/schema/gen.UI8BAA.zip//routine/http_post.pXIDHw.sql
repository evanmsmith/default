create function http_post(uri character varying, content character varying, content_type character varying) returns gen.http_response
    language sql
as
$$
SELECT http(('POST', $1, NULL, $3, $2)::http_request)
$$;

alter function http_post(varchar, varchar, varchar) owner to mb;

