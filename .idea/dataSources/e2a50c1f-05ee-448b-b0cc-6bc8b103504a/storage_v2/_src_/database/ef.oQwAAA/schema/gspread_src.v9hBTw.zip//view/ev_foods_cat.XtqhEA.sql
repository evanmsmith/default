create view ev_foods_cat(category) as
SELECT ev_foods.category
FROM gspread_src.ev_foods
GROUP BY ev_foods.category;

alter table ev_foods_cat
    owner to mb;

