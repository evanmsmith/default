create view most_effective_short_food(inv, food, usage) as
WITH short_inv AS (
    SELECT recipe_shortage.inv,
           recipe_shortage.rec,
           recipe_shortage.food
    FROM household.recipe_shortage
    WHERE recipe_shortage.shortage = 1::numeric
)
SELECT short_inv.inv,
       food_usage.food,
       food_usage.usage
FROM recipe.food_usage
         JOIN short_inv USING (food)
GROUP BY short_inv.inv, food_usage.food, food_usage.usage
ORDER BY food_usage.usage DESC;

alter table most_effective_short_food
    owner to mb;

