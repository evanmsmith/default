create view diet_det(diet, food, food_pref) as
SELECT diet_det_sparse.diet,
       diet_det_sparse.food,
       diet_det_sparse.food_pref
FROM diet.diet_det_sparse
UNION ALL
SELECT diet.diet,
       food.food::food.food_t                                           AS food,
       ROW (0::double precision, 1::double precision)::diet.food_pref_t AS food_pref
FROM diet.diet
         CROSS JOIN food.food
WHERE NOT ((diet.diet, food.food) IN (SELECT diet_det_sparse.diet,
                                             diet_det_sparse.food
                                      FROM diet.diet_det_sparse));

alter table diet_det
    owner to mb;

