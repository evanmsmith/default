create view recipe_shortage(rec, inv, food, shortage) as
SELECT bom_det.rec,
       item_dense.inv,
       bom_det.food,
       bom_det.bom_qty::numeric - item_dense.inv_qty::numeric AS shortage
FROM recipe.bom_det
         JOIN household.item_dense USING (food);

alter table recipe_shortage
    owner to mb;

