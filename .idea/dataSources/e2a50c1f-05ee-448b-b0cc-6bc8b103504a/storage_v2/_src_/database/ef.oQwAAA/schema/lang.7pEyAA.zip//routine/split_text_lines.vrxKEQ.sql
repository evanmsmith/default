create function split_text_lines(text)
    returns TABLE(line text, lineno integer)
    immutable
    strict
    language sql
as
$$
SELECT
  line,
  lineno::integer
 FROM
  unnest(regexp_split_to_array($1, E'\n'))
   WITH ORDINALITY lines(line, lineno)
$$;

alter function split_text_lines(text) owner to mb;

