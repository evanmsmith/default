create view house_recipe_diet_sum(house, rec, persons, diets, food_pref, tolerated, foods_total) as
SELECT house.house,
       recipe_diet_sum.rec,
       array_agg(person.person)                                                                                        AS persons,
       array_agg(person_diet.diet)                                                                                     AS diets,
       ROW (avg((recipe_diet_sum.food_pref).preference), min((recipe_diet_sum.food_pref).tolerance))::diet.food_pref_t AS food_pref,
       bool_and(recipe_diet_sum.tolerated)                                                                             AS tolerated,
       recipe_diet_sum.foods_total
FROM household.house
         JOIN household.person USING (house)
         JOIN household.person_diet USING (person)
         JOIN household.recipe_diet_sum USING (diet)
GROUP BY house.house, recipe_diet_sum.rec, recipe_diet_sum.foods_total;

alter table house_recipe_diet_sum
    owner to mb;

