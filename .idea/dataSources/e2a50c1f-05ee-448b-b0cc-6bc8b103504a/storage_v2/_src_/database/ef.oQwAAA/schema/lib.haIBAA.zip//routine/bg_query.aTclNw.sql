create function bg_query(_application text, _query text) returns void
    language plpgsql
as
$$
BEGIN
 -- This function relies on trust authentication being enabled for
 -- 127.0.0.1. This design needs to be improved in future.
 IF 'bgquery' IN (SELECT unnest FROM unnest(lib.dblink_get_connections())) THEN
  PERFORM lib.dblink_disconnect('bgquery');
 END IF;
 PERFORM lib.dblink_connect_u('bgquery', 'hostaddr=127.0.0.1'
 || ' dbname=' || current_database()
 || ' user=' || current_user
 || ' application_name=' || _application);
 -- Pass search path through to the remote end.
 IF lib.dblink_send_query('bgquery',
  'SET search_path = '''
  || (SELECT string_agg(unnest, ',') FROM unnest(current_schemas(false)))
  || '''; ' || _query
 ) = 0 THEN
  RAISE EXCEPTION 'Failed to send bg query: %', _query;
 END IF;
END
$$;

comment on function bg_query(text, text) is 'Spawn a query running in a new connection context in the background, returning immediately; throwing away any result. The query string can consist of multiple queries separated by ;.';

alter function bg_query(text, text) owner to mb;

