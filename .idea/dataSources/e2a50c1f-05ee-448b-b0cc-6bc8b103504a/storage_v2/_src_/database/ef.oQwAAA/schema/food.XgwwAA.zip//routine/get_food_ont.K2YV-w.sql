create function get_food_ont(bigint) returns gen.label_t
    stable
    strict
    language sql
as
$$
SELECT food_ont_label FROM food_ont WHERE food_ont = $1
$$;

alter function get_food_ont(bigint) owner to mb;

