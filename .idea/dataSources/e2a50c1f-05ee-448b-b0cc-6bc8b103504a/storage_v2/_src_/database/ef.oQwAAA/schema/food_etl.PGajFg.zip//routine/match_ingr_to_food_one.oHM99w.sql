create function match_ingr_to_food_one(text)
    returns TABLE(food bigint, confidence real)
    stable
    strict
    language sql
as
$$
SELECT * FROM match_ingr_to_food($1) LIMIT 1;
$$;

alter function match_ingr_to_food_one(text) owner to mb;

