create view recipe_class_summary("Ontology", "Class", "Details", "Occurences") as
SELECT rec_ont.rec_ont_label      AS "Ontology",
       rec_class.rec_class        AS "Class",
       rec_class.rec_class_note   AS "Details",
       count(rec_class.rec_class) AS "Occurences"
FROM recipe.rec_class
         JOIN recipe.rec_ont USING (rec_ont)
GROUP BY rec_ont.rec_ont_label, rec_class.rec_class, rec_class.rec_class_note
ORDER BY rec_ont.rec_ont_label, rec_class.rec_class;

alter table recipe_class_summary
    owner to mb;

