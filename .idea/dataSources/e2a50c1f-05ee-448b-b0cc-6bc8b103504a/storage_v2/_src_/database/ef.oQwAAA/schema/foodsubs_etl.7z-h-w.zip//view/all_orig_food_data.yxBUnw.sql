create view all_orig_food_data
            (food, food_label, src, spn_id, image_uri, units, orig_json, possible_names, url, page_hierarchy1,
             page_hierarchy2, page_hierarchy3, page_hierarchy4, substitutes, notes, to_make, pronunciation,
             shopping_hints, equivalents, complements, tips, cooking_hints, where_to_find)
as
SELECT COALESCE(spn_indata.food, fs_indata.food)                   AS food,
       COALESCE(spn_indata.food_label::text, fs_indata.food_label) AS food_label,
       CASE
           WHEN spn_indata.food IS NOT NULL THEN 'spn'::text
           WHEN fs_indata.food IS NOT NULL THEN 'fs'::text
           ELSE NULL::text
           END                                                     AS src,
       spn_indata.spn_id,
       spn_indata.image_uri,
       spn_indata.units,
       spn_indata.orig_json,
       fs_indata.possible_names,
       fs_indata.url,
       fs_indata.page_hierarchy1,
       fs_indata.page_hierarchy2,
       fs_indata.page_hierarchy3,
       fs_indata.page_hierarchy4,
       fs_indata.substitutes,
       fs_indata.notes,
       fs_indata.to_make,
       fs_indata.pronunciation,
       fs_indata.shopping_hints,
       fs_indata.equivalents,
       fs_indata.complements,
       fs_indata.tips,
       fs_indata.cooking_hints,
       fs_indata.where_to_find
FROM spn_food_etl.spn_indata
         FULL JOIN foodsubs_etl.fs_indata USING (food);

alter table all_orig_food_data
    owner to mb;

