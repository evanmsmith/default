create function get_food(bigint) returns gen.label_t
    stable
    strict
    language sql
as
$$
SELECT food_label FROM food_name WHERE food = $1 AND prio = 1
$$;

alter function get_food(bigint) owner to mb;

