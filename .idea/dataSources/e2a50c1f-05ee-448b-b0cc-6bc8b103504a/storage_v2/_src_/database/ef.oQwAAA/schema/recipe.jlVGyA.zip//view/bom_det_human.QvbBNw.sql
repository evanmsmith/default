create view bom_det_human (rec, rec_label, lineno, section, food, food_label, qty_descr, confidence, orig_text) as
SELECT etl_det.rec,
       recipe.rec_label,
       etl_det.lineno,
       etl_det.section,
       food_main_name.food,
       food_main_name.food_label,
       etl_det.qty_descr,
       etl_det.confidence,
       etl_det.orig_text
FROM food_etl.etl_det
         JOIN recipe.recipe USING (rec)
         JOIN food.food_main_name USING (food);

alter table bom_det_human
    owner to mb;

