create function ont_etl1_load1(dat ont_etl.ont_etl1_row1_t, _source text) returns void
    strict
    language sql
as
$$
    -- The logic is:
 --
 -- Anywhere cl appears in rec_class within the old_ont ontology (and
 -- optionally with the old_note rec_class_note), create a new
 -- rec_class record with new_ont as ontology, and (existing) cl as
 -- class.
 --
 WITH ontology AS (
  INSERT INTO rec_ont (rec_ont_label)
  VALUES (dat.new_ont)
  -- null update required so that rec_ont can always be returned
  ON CONFLICT (rec_ont_label) DO UPDATE
   -- SET rec_ont = (rec_ont).rec_ont
   SET rec_ont_label = rec_ont.rec_ont_label
  RETURNING rec_ont
 ),
 etl_data AS (
  INSERT INTO ont_etl_data SELECT
   rc.rec,
   dat.new_ont,
   dat.old_class,
   dat.new_note,
   _source,
   dat.new_ref
  FROM
   rec_class rc
  WHERE
   rc.rec_ont = get_rec_ont(dat.old_ont) AND
   rc.rec_class = dat.old_class AND
   (dat.old_note IS NULL OR rc.rec_class_note = dat.old_note)
  RETURNING rec
 )
 INSERT INTO rec_class
 SELECT
  etl_data.rec,
  ontology.rec_ont,
  dat.old_class,
  NULL
 FROM
  ontology,
  etl_data
 ;
$$;

alter function ont_etl1_load1(ont_etl.ont_etl1_row1_t, text) owner to mb;

