create view recipe_diet_food_sum (diet, rec, food_pref, foods_total, foods_in_diet, foods_tolerated, tolerated) as
SELECT f.diet,
       f.rec,
       ROW (avg((f.food_pref).preference), min((f.food_pref).tolerance))::diet.food_pref_t AS food_pref,
       count(f.food)                                                                       AS foods_total,
       sum(
               CASE
                   WHEN f.in_diet THEN 1
                   ELSE 0
                   END)                                                                    AS foods_in_diet,
       sum(
               CASE
                   WHEN f.tolerated THEN 1
                   ELSE 0
                   END)                                                                    AS foods_tolerated,
       bool_and(f.tolerated)                                                               AS tolerated
FROM household.recipe_diet_food f
GROUP BY f.rec, f.diet;

alter table recipe_diet_food_sum
    owner to mb;

