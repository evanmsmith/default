create view efapp_possible_recipe_bom
            (house, house_label, inv, rec, rec_label, food, food_label, sufficient, shortage) as
SELECT house.house,
       house.house_label,
       inventory.inv,
       possible_recipe_bom.rec,
       recipe.rec_label,
       food.food,
       food.get_food(food.food) AS food_label,
       possible_recipe_bom.sufficient,
       possible_recipe_bom.shortage
FROM household.house
         JOIN household.inventory USING (house)
         JOIN household.possible_recipe_bom USING (inv)
         JOIN recipe.recipe USING (rec)
         JOIN food.food USING (food);

alter table efapp_possible_recipe_bom
    owner to mb;

