create function safe_cast(_val anyelement, _type text) returns anyelement
    immutable
    language plpgsql
as
$$
DECLARE
 _out record;
BEGIN
 EXECUTE 'SELECT cast($1 as ' || _type || ') AS result' USING _val INTO _out;
 RETURN _out.result;
EXCEPTION
 WHEN OTHERS THEN
  --RAISE NOTICE 'Validation failed % %', SQLERRM, SQLSTATE;
  RETURN null;
END
$$;

alter function safe_cast(anyelement, text) owner to mb;

