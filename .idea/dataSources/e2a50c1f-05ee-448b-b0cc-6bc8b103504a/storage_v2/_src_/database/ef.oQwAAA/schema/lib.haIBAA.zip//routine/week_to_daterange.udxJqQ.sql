create function week_to_daterange(_year1 integer, _week1 integer, _year2 integer, _week2 integer) returns daterange
    immutable
    SET search_path = lib
    language sql
as
$$
SELECT
  ('[' || week_to_date(_year1, _week1, 1)::text ||
  ',' ||
  week_to_date(_year2, _week2, 7)::text || ']')::daterange
 ;

$$;

alter function week_to_daterange(integer, integer, integer, integer) owner to mb;

