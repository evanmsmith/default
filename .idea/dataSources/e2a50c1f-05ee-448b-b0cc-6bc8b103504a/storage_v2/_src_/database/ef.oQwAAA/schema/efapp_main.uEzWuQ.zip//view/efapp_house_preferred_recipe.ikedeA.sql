create view efapp_house_preferred_recipe("House", "Persons", "Recipe", "Preference Score %") as
SELECT household.get_house(house_recipe_diet_sum.house)                                      AS "House",
       (SELECT string_agg(household.get_person(unnest.unnest), ', '::text
                          ORDER BY (household.get_person(unnest.unnest))) AS string_agg
        FROM unnest(house_recipe_diet_sum.persons) unnest(unnest))                           AS "Persons",
       recipe.get_rec(house_recipe_diet_sum.rec)                                             AS "Recipe",
       ((house_recipe_diet_sum.food_pref).preference * 100::double precision)::numeric(5, 2) AS "Preference Score %"
FROM household.house_recipe_diet_sum
WHERE house_recipe_diet_sum.tolerated
ORDER BY ((house_recipe_diet_sum.food_pref).preference) DESC, (recipe.get_rec(house_recipe_diet_sum.rec));

alter table efapp_house_preferred_recipe
    owner to mb;

