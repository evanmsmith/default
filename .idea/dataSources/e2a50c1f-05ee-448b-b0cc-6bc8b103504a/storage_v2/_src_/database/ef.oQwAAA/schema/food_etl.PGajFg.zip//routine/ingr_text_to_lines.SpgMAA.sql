create function ingr_text_to_lines(data text, ingr_re text, section_re text) returns SETOF food_etl.ingr_line_t
    immutable
    strict
    language sql
as
$$
SELECT
  section,
  ingr_line,
  row_number() OVER (ORDER BY lineno)::integer lineno
 FROM
 (
  SELECT
   (
    SELECT
     substring(line from section_re)
    FROM
     split_text_lines(data) b
    WHERE
     b.lineno <= a.lineno AND
     substring(line from section_re) IS NOT NULL
    ORDER BY b.lineno DESC LIMIT 1
   ) section,
   substring(line from ingr_re) ingr_line,
   lineno
  FROM
   split_text_lines(data) a
 ) aa
 WHERE
  ingr_line IS NOT NULL
 ;
$$;

alter function ingr_text_to_lines(text, text, text) owner to mb;

