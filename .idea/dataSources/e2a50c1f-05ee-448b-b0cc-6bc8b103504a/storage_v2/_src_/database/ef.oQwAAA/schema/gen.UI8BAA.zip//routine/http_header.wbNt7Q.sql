create function http_header(field character varying, value character varying) returns gen.http_header
    language sql
as
$$
SELECT $1, $2
$$;

alter function http_header(varchar, varchar) owner to mb;

