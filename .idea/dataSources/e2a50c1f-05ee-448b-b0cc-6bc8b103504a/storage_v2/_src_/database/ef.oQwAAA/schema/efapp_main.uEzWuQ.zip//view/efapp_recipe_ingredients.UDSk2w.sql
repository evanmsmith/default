create view efapp_recipe_ingredients
            ("Recipe Identifier", "Title", "Line no.", "Section", "Food", "Source", "Quantity", "Confidence",
             "Original text") as
SELECT bom_det_human.rec        AS "Recipe Identifier",
       bom_det_human.rec_label  AS "Title",
       bom_det_human.lineno     AS "Line no.",
       bom_det_human.section    AS "Section",
       bom_det_human.food_label AS "Food",
       food_source.src          AS "Source",
       bom_det_human.qty_descr  AS "Quantity",
       bom_det_human.confidence AS "Confidence",
       bom_det_human.orig_text  AS "Original text"
FROM recipe.bom_det_human
         JOIN debug.food_source USING (food)
ORDER BY bom_det_human.rec_label, bom_det_human.lineno;

alter table efapp_recipe_ingredients
    owner to mb;

