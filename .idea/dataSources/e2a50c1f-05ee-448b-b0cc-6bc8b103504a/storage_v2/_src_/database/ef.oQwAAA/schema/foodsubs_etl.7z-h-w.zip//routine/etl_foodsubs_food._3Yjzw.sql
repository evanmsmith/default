create function etl_foodsubs_food(fs_data foodsubs_etl.foodsubs_foods) returns bigint
    strict
    SET search_path = foodsubs_etl, gspread_src, food, gen, lib
    language sql
as
$$
WITH existing_food AS (
  SELECT food FROM fs_food WHERE
   food_main_name = fs_data.labels[1]
 ),
 ins_food AS (
  INSERT INTO food
  SELECT
  WHERE
   fs_data.labels[1] NOT IN (SELECT food_main_name FROM fs_food)
  RETURNING food
 ),
 actual_food AS (
  SELECT
   coalesce(existing_food.food, ins_food.food) food
  FROM
   (VALUES (1)) dual
   LEFT JOIN existing_food ON true
   LEFT JOIN ins_food ON true
 ),
 ins_food_names AS (
  INSERT INTO food_name (food, food_label, prio)
  SELECT food, label, prio
  FROM ins_food, unnest(fs_data.labels) WITH ORDINALITY labels(label, prio)
  -- ON CONFLICT (food_label) DO NOTHING
  WHERE NOT EXISTS (
   SELECT food_label FROM food_name
    WHERE prio = 1 AND food_label = ANY(fs_data.labels)
  )
 ),
 ins_food_class AS (
  INSERT INTO food_class (food, food_ont, food_class)
   SELECT food, get_food_ont('fs-cat1'), fs_data.cat1
   FROM ins_food WHERE fs_data.cat1 != ''
  UNION ALL
   SELECT food, get_food_ont('fs-cat2'), fs_data.cat2
   FROM ins_food WHERE fs_data.cat2 != ''
  UNION ALL
   SELECT food, get_food_ont('fs-cat3'), fs_data.cat3
   FROM ins_food WHERE fs_data.cat3 != ''
  UNION ALL
   SELECT food, get_food_ont('fs-cat4'), fs_data.cat4
   FROM ins_food WHERE fs_data.cat4 != ''
  ON CONFLICT ON CONSTRAINT food_class_pkey DO NOTHING
 ),
 ins_fs_food AS (
  INSERT INTO fs_food
  SELECT
   food,
   fs_data.labels[1] food_main_name
  FROM
   actual_food
  ON CONFLICT ON CONSTRAINT fs_food_pkey DO NOTHING
 )
 SELECT
  food
 FROM
  actual_food
 ;
$$;

alter function etl_foodsubs_food(foodsubs_etl.foodsubs_foods) owner to mb;

