create function tsv_split_array(_dict regconfig, _string text) returns text[]
    immutable
    strict
    language sql
as
$$
SELECT array_agg(lexeme ORDER BY pos)
 FROM
  unnest(to_tsvector($1, $2)) arr,
  unnest(positions) pos
 ;
$$;

alter function tsv_split_array(regconfig, text) owner to mb;

