create view diet_det_sparse(diet, food, food_pref) as
SELECT diet_det_food.diet,
       diet_det_food.food,
       diet_det_food.food_pref
FROM diet.diet_det_food
UNION ALL
SELECT diet_det_class.diet,
       food_class.food::food.food_t AS food,
       diet_det_class.food_pref
FROM diet.diet_det_class
         JOIN food.food_class USING (food_ont, food_class);

alter table diet_det_sparse
    owner to mb;

