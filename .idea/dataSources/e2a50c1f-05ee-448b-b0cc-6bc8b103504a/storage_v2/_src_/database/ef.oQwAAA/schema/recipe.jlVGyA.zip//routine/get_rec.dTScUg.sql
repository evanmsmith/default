create function get_rec(bigint) returns gen.label_t
    stable
    strict
    SET search_path = recipe, food, gen
    language sql
as
$$
SELECT rec_label FROM recipe WHERE rec = $1
$$;

alter function get_rec(bigint) owner to mb;

