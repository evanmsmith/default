create view lang_part(word, part) as
SELECT bnc_ak_lemma.lemma                  AS word,
       bnc_ak_lemma.part::lang.lang_part_t AS part
FROM lang.bnc_ak_lemma;

alter table lang_part
    owner to mb;

