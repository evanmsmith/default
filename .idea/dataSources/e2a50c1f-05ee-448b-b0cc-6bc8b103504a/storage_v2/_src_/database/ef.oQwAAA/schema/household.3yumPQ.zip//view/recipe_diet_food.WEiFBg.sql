create view recipe_diet_food(diet, rec, food, food_pref, tolerated, in_diet) as
SELECT diet.diet,
       recipe.rec,
       bom_det.food,
       diet_det.food_pref,
       (diet_det.food_pref).tolerance <> 0::double precision OR diet_det.food_pref IS NULL AS tolerated,
       diet_det.food_pref IS NOT NULL                                                      AS in_diet
FROM recipe.recipe
         CROSS JOIN diet.diet
         JOIN recipe.bom_det USING (rec)
         JOIN diet.diet_det USING (diet, food);

alter table recipe_diet_food
    owner to mb;

