create view food_commonness_agg(food_id, food_name, food_classes, sum, in_pantry) as
SELECT food_commonness_de_agg.food_id,
       food_commonness_de_agg.food_name,
       food_commonness_de_agg.food_classes,
       sum(food_commonness_de_agg.food_commonness) AS sum,
       max(food_commonness_de_agg.in_pantry)       AS in_pantry
FROM food.food_commonness_de_agg
GROUP BY food_commonness_de_agg.food_id, food_commonness_de_agg.food_name, food_commonness_de_agg.food_classes;

alter table food_commonness_agg
    owner to mbtemp;

