create function efapp_possible_recipe_with_ingredients(gen.label_t[], all_any text)
    returns TABLE("Recipe Identifier" bigint, "Title" gen.label_t)
    stable
    strict
    SET search_path = efapp_main, household, food, recipe, gen
    language sql
as
$$
SELECT
  rec,
  rec_label
 FROM
  possible_recipe_with_ingredients(
   (SELECT array_agg(get_food(f)) FROM unnest($1) f), all_any
  ) possible
  JOIN recipe USING (rec)
 ;
$$;

alter function efapp_possible_recipe_with_ingredients(gen.label_t[], text) owner to mb;

