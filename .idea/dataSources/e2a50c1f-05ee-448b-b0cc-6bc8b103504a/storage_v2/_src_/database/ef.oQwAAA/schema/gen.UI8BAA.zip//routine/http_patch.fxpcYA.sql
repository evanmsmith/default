create function http_patch(uri character varying, content character varying, content_type character varying) returns gen.http_response
    language sql
as
$$
SELECT http(('PATCH', $1, NULL, $3, $2)::http_request)
$$;

alter function http_patch(varchar, varchar, varchar) owner to mb;

