create view efapp_most_effective_short_food("Inventory", "Food", "Usage") as
SELECT most_effective_short_food.inv   AS "Inventory",
       food.get_food(food.food)        AS "Food",
       most_effective_short_food.usage AS "Usage"
FROM household.most_effective_short_food
         JOIN food.food USING (food)
LIMIT 100;

alter table efapp_most_effective_short_food
    owner to mb;

