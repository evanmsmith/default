create view efapp_house_inv_diet_possible_recipe
            ("House", "Recipe", "Rating", "No. Ratings", "URL", "Persons", "All In Inv", "No. Ingredients",
             "Available Ingredients", "Not Available Ingredients", "Preferred Ingredients", "Unpreferred Ingredients",
             "Classes", "Class Tolerated", "Source", num_missing)
as
SELECT household.get_house(r.house)                          AS "House",
       recipe.get_rec(r.rec)                                 AS "Recipe",
       (recipe_rating.rating * 5::double precision)::integer AS "Rating",
       recipe_rating.num_ratings                             AS "No. Ratings",
       'http://foo/bar'::text                                AS "URL",
       (SELECT string_agg(household.get_person(person.person), ', '::text) AS string_agg
        FROM household.person
        WHERE person.house = r.house)                        AS "Persons",
       r.num_missing = 0                                     AS "All In Inv",
       (r.num_present || ' of '::text) || r.foods_total      AS "No. Ingredients",
       food.food_array_human(r.present_foods)                AS "Available Ingredients",
       food.food_array_human(r.missing_foods)                AS "Not Available Ingredients",
       ARRAY []::text[]                                      AS "Preferred Ingredients",
       ARRAY []::text[]                                      AS "Unpreferred Ingredients",
       ARRAY []::text[]                                      AS "Classes",
       ARRAY []::text[]                                      AS "Class Tolerated",
       etl_recipe.source                                     AS "Source",
       r.num_missing
FROM efapp_main.house_diet_possible_recipe r
         LEFT JOIN food_etl.etl_recipe USING (rec)
         LEFT JOIN recipe.recipe_rating USING (rec);

alter table efapp_house_inv_diet_possible_recipe
    owner to mb;

