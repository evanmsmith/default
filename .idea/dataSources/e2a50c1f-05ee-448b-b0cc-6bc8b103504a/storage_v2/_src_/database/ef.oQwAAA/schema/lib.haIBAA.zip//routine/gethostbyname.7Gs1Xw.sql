create function gethostbyname(hostname text) returns inet
    security definer
    language plpythonu
as
$$
 import socket
 return socket.gethostbyname(hostname)
$$;

alter function gethostbyname(text) owner to mb;

