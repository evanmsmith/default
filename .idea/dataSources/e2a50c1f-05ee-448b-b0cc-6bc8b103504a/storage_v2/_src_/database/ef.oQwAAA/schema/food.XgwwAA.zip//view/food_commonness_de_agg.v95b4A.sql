create view food_commonness_de_agg(food_id, food_name, food_classes, food_commonness, in_pantry) as
SELECT f.food                  AS food_id,
       f.initcap               AS food_name,
       f.string_agg            AS food_classes,
       sum(t.normalized_score) AS food_commonness,
       f.in_pantry
FROM food.food_commonness f
         LEFT JOIN (SELECT DISTINCT food_commonness.initcap,
                                    food_commonness.z_score,
                                    CASE
                                        WHEN food_commonness.z_score <> 0::numeric THEN (food_commonness.z_score -
                                                                                         ((SELECT min(food_commonness_1.z_score) AS min
                                                                                           FROM food.food_commonness food_commonness_1))) /
                                                                                        (((SELECT max(food_commonness_1.z_score) AS max
                                                                                           FROM food.food_commonness food_commonness_1)) -
                                                                                         ((SELECT min(food_commonness_1.z_score) AS min
                                                                                           FROM food.food_commonness food_commonness_1)))
                                        ELSE 0::numeric
                                        END AS normalized_score
                    FROM food.food_commonness
                    GROUP BY food_commonness.food, food_commonness.z_score, food_commonness.initcap) t
                   ON t.initcap = f.initcap
GROUP BY f.food, f.initcap, f.string_agg, f.in_pantry;

alter table food_commonness_de_agg
    owner to mbtemp;

