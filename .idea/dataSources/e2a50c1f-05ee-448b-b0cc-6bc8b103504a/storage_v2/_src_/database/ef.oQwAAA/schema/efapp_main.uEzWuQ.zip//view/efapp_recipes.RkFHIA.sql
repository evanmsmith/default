create view efapp_recipes ("Recipe Identifier", "Title", "Total ingredients", "Ingredients matched to inventory") as
SELECT bom_det_human.rec               AS "Recipe Identifier",
       bom_det_human.rec_label         AS "Title",
       count(*)                        AS "Total ingredients",
       count(bom_det_human.food_label) AS "Ingredients matched to inventory"
FROM recipe.bom_det_human
GROUP BY bom_det_human.rec, bom_det_human.rec_label
ORDER BY bom_det_human.rec_label;

alter table efapp_recipes
    owner to mb;

