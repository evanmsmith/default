create function validate_type(_val anyelement, _type text) returns boolean
    immutable
    language plpgsql
as
$$
BEGIN
 EXECUTE 'SELECT cast($1 as ' || _type || ')' USING _val;
 RETURN true;
EXCEPTION
 WHEN OTHERS THEN
  --RAISE NOTICE 'Validation failed % %', SQLERRM, SQLSTATE;
  RETURN false;
END
$$;

alter function validate_type(anyelement, text) owner to mb;

