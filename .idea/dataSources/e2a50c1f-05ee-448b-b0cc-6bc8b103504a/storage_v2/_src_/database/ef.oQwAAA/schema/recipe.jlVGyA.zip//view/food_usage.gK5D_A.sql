create view food_usage(food, usage) as
SELECT bom_det.food,
       count(*) AS usage
FROM recipe.bom_det
GROUP BY bom_det.food;

alter table food_usage
    owner to mb;

