create function ont_etl1_do_nyt() returns void
    stable
    strict
    SET search_path = ont_etl, recipe, gen
    language sql
as
$$
SELECT
  ont_etl1_load1(dat, 'nyt-tag')
 FROM
  ont_etl1_nyt_data;
$$;

alter function ont_etl1_do_nyt() owner to mb;

