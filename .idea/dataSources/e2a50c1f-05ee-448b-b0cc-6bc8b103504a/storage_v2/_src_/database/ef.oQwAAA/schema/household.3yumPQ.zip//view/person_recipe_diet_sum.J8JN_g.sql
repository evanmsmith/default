create view person_recipe_diet_sum
            (person, diet_label, diet_prio, diet, rec, food_pref, foods_total, foods_in_diet, foods_tolerated,
             tolerated) as
SELECT person_diet.person,
       person_diet.diet_label,
       person_diet.diet_prio,
       recipe_diet_sum.diet,
       recipe_diet_sum.rec,
       recipe_diet_sum.food_pref,
       recipe_diet_sum.foods_total,
       recipe_diet_sum.foods_in_diet,
       recipe_diet_sum.foods_tolerated,
       recipe_diet_sum.tolerated
FROM household.person_diet
         JOIN diet.diet USING (diet)
         JOIN household.recipe_diet_sum USING (diet);

alter table person_recipe_diet_sum
    owner to mb;

