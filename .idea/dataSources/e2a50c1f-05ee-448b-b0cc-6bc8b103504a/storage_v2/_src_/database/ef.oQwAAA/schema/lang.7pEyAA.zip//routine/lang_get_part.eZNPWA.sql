create function lang_get_part(text) returns SETOF lang.lang_part_t
    immutable
    strict
    language sql
as
$$
SELECT part FROM lang_part WHERE word = $1;
$$;

alter function lang_get_part(text) owner to mb;

