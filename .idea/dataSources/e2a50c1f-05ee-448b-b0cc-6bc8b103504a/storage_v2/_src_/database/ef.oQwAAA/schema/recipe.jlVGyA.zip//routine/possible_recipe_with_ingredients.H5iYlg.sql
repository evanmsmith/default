create function possible_recipe_with_ingredients(food.food_t[], all_any text)
    returns TABLE(rec bigint)
    stable
    strict
    language sql
as
$$
SELECT
  rec
 FROM
  (
   SELECT
    rec,
    array_agg(food) foods
   FROM
    bom_det
   GROUP BY
    rec
  ) f
 WHERE
  CASE
   WHEN all_any = 'all' THEN $1 <@ foods
   WHEN all_any = 'any' THEN $1 && foods
   ELSE false
  END
$$;

alter function possible_recipe_with_ingredients(food.food_t[], text) owner to mb;

