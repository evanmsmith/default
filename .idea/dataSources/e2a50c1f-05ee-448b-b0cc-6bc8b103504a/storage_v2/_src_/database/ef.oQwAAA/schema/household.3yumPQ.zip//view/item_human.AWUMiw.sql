create view item_human(inv, food, food_human, classes_human, inv_qty) as
SELECT item_dense.inv,
       item_dense.food,
       food.get_food(item_dense.food::bigint)                      AS food_human,
       (SELECT string_agg(((food_ont_class_human.food_class::text || '['::text) ||
                           food_ont_class_human.food_ont_label::text) || ']'::text, ', '::text) AS string_agg
        FROM food.food_ont_class_human
        WHERE food_ont_class_human.food = item_dense.food::bigint) AS classes_human,
       item_dense.inv_qty
FROM household.item_dense;

alter table item_human
    owner to mb;

